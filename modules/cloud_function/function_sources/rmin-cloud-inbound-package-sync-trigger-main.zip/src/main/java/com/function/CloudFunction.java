package com.function;


import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.google.cloud.functions.CloudEventsFunction;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.events.cloud.firestore.v1.DocumentEventData;
import com.google.events.cloud.firestore.v1.Value;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.ByteString;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;

import io.cloudevents.CloudEvent;


public class CloudFunction implements CloudEventsFunction {

    public static final String IMPBNUMBERKEY = "ImpbNumberKey";
    private static final Logger logger = Logger.getLogger(CloudFunction.class.getName());


  private final int inboundPackagePartitions = Integer.parseInt(System.getenv("inboundPackagePartitions"));
  private Publisher publisher;

  @Override
  public void accept(CloudEvent event) throws InvalidProtocolBufferException {


      try {
          publisher = InboundPackagePubsub.getPubSub();

          DocumentEventData firestorEventData = DocumentEventData.parseFrom(event.getData().toBytes());

          String newZip11 = "";
          String newShipperName = "";
          String newImpb = "";
          String newSerialNumber = "";
          String newMailerID = "";
          String newDeliveryDate = "";
          String oldDeliveryDate = "";
          String oldImpb = "";
          String oldZip11 = "";


          if (!firestorEventData.getOldValue().toString().isBlank()) {
              Map<String, Value> oldFields = firestorEventData.getOldValue().getFieldsMap();
              oldDeliveryDate = oldFields.get("deliveryDate").getStringValue();
              oldImpb = oldFields.get("impb").getStringValue();
              oldZip11 = oldFields.get("zip11").getStringValue();
          }


          if (!firestorEventData.getValue().toString().isBlank()) {
              Map<String, Value> fields = firestorEventData.getValue().getFieldsMap();
              newZip11 = fields.get("zip11").getStringValue();
              newShipperName = fields.get("shipperName").getStringValue();
              newImpb = fields.get("impb").getStringValue();
              newSerialNumber = fields.get("serialNumber").getStringValue();
              newMailerID = fields.get("mailerID").getStringValue();
              newDeliveryDate = fields.get("deliveryDate").getStringValue();

            if(!newDeliveryDate.equals(oldDeliveryDate)) {
                try {
                    JSONObject packageSyncMsg = new JSONObject();

                    packageSyncMsg.put("newZip11", newZip11);
                    packageSyncMsg.put("newShipperName", newShipperName);
                    packageSyncMsg.put("newImpb", newImpb);
                    packageSyncMsg.put("newSerialNumber", newSerialNumber);
                    packageSyncMsg.put("newMailerID", newMailerID);
                    packageSyncMsg.put("newDeliveryDate", newDeliveryDate);
                    packageSyncMsg.put("oldDeliveryDate", oldDeliveryDate);
                    packageSyncMsg.put("oldImpb", oldImpb);
                    packageSyncMsg.put("oldZip11", oldZip11);

                    HashMap<String, String> attributes = new HashMap<>();
                    attributes.put(
                            IMPBNUMBERKEY,
                            String.valueOf(
                                    getImpbNumberKey(newImpb)));

                    PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
                            .setData(ByteString.copyFromUtf8(packageSyncMsg.toString()))
                            .putAllAttributes(attributes)
                            .build();
                    publisher.publish(pubsubMessage);
                } catch (Exception e) {
                    String message = new StringBuilder().append("Error Publishing Messages to the Topic: ")
                            .append("Exception: ")
                            .append(ExceptionUtils.getStackTrace(e))
                            .toString();

                    logger.log(Level.INFO, message);
                }
            }
          }
      } catch (Exception e) {
          String message = new StringBuilder().append("Error: ")
                  .append("Exception: ")
                  .append(ExceptionUtils.getStackTrace(e))
                  .toString();

          logger.log(Level.INFO, message);
      }

  }

    private int getImpbNumberKey(String newImpb) {
        int newImpbNumberHashCode = newImpb.hashCode();
        if (newImpbNumberHashCode < 0) {
            newImpbNumberHashCode = newImpbNumberHashCode * -1;
        }
        return (newImpbNumberHashCode % inboundPackagePartitions) + 1;
    }

  }
