package com.function;

import com.google.cloud.bigquery.*;
import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import redis.clients.jedis.Jedis;

import java.util.logging.Logger;

import java.io.IOException;


public class Zip5SyncFunction implements HttpFunction {
    private static final Logger LOGGER = Logger.getLogger(Zip5SyncFunction.class.getName());

    @Override
    public void service(HttpRequest request, HttpResponse response) throws IOException {

        try {

            var projectId = System.getenv("OUTPUT_PROJ");
            var tableName = System.getenv("BIGQUERY_TABLE");
            var redisHost = System.getenv("REDIS_HOST");
            var redisPort = Integer.parseInt(System.getenv("REDIS_PORT"));
            var zip5Count = 0;

            BigQuery bigquery = BigQueryOptions.newBuilder().setProjectId(projectId).build().getService();

            String query = "SELECT * FROM `" + tableName + "`;";

            QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).build();

            Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).build());
            queryJob = queryJob.waitFor();

            if (queryJob == null) {
                throw new Exception("Job No Longer Exists");
            }

            if (queryJob.getStatus().getError() != null) {
                throw new Exception(queryJob.getStatus().getError().toString());
            }

            TableResult results = queryJob.getQueryResults();

            try(var jedis = new Jedis(redisHost, redisPort)) {

                for(FieldValueList row: results.iterateAll()) {
                    String zip5 = row.get("ZIP5").getStringValue();
                    jedis.sadd("delivery_notifications", zip5);
                    zip5Count++;

                }

            } catch(Exception e) {
                LOGGER.info("Error Syncing Cahce: " + e);
            }


            LOGGER.info(zip5Count + "Zip5's Have Successfully Sync To Cache");

        } catch(Exception e) {
            LOGGER.info("Error: " + e);
        }
    }
}
