# rmin-cloud-zip5-timezone-func

## Local Build

```shell
mvn install -D"https.protocols"=TLSv1.2
```

## Deploy 

### DEV

```shell
gcloud functions deploy rmin-cloud-zip5-timezone-func \
--gen2 \
--region=us-east4 \
--runtime=java11 \
--trigger-http \
--entry-point=com.function.CloudFunction \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/upscio-it-idc-9060-03d/locations/us-east4/connectors/rmin-dev-serverless-conn \
--timeout=540s \
--service-account=dev-zip5-tz-func@upscio-it-idc-9060-03d.iam.gserviceaccount.com \
--set-env-vars=REDIS_HOST=10.100.1.4,REDIS_PORT=6379,REDIS_TTL=259200,OUTPUT_PROJ=upscio-it-idc-9060-03d,BIGQUERY_TABLE=upscio-it-idc-9060-03d.rmin_operationaldata_bigquery_e_003d.ZIP5_TIMEZONE
```

### SIT

```shell
gcloud functions deploy rmin-cloud-zip5-timezone-func \
--gen2 \
--region=us-east4 \
--runtime=java11 \
--trigger-http \
--entry-point=com.function.CloudFunction \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn \
--timeout=540s \
--service-account=--service-account=SIT-zip5-tz-func@uspscio-idc-9060-01s.iam.gserviceaccount.com \
--set-env-vars=REDIS_HOST=10.100.1.84,REDIS_PORT=6379,REDIS_TTL=259200,OUTPUT_PROJ=uspscio-idc-9060-01s,BIGQUERY_TABLE=uspscio-idc-9060-01s.rmin_operationaldata_bigquery_e_001s.ZIP5_TIMEZONE

### PERF

```shell
gcloud functions deploy rmin-cloud-zip5-timezone-func \
--gen2 \
--region=us-east4 \
--runtime=java11 \
--trigger-http \
--entry-point=com.function.CloudFunction \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn \
--timeout=540s \
--service-account=--service-account=dev-zip5-tz-func@uspscio-idc-9060-01d.iam.gserviceaccount.com \
--set-env-vars=REDIS_HOST=10.100.1.151,REDIS_PORT=6379,REDIS_TTL=259200,OUTPUT_PROJ=uspscio-idc-9060-01d,BIGQUERY_TABLE=uspscio-idc-9060-01d.rmin_operationaldata_bigquery_e_001d.ZIP5_TIMEZONE
```