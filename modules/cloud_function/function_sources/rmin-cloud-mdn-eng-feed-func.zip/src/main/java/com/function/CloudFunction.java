package com.function;

import com.azure.core.util.BinaryData;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.google.api.gax.paging.Page;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.functions.CloudEventsFunction;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.CopyWriter;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.protobuf.InvalidProtocolBufferException;
import io.cloudevents.CloudEvent;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class CloudFunction implements CloudEventsFunction {
    
    private static final Logger LOG = Logger.getLogger(CloudFunction.class.getName());
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss").withZone(ZoneId.of("UTC"));
    private static final DateTimeFormatter FILE_DATETIME_FORMATTER = DateTimeFormatter.ofPattern("MM_dd_yyy_HH_mm");
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MM-dd-yyy");
    private static LocalDateTime startTime = LocalDateTime.now();
    private static String transactionDate = DATE_FORMATTER.format(LocalDate.now());
    private static final String DEFAULT = "DEFAULT";
    private static final String FAILURE = "FAILURE FUNCTION";
    private static final String SUCCESS = "SUCCESS FUNCTION";
    private static final String UPLOAD_ERROR_MESSAGE = "'Error Copying File'";
    private static final String TOGGLE_ERROR_MESSAGE = "'Eng Feed Toggled Off'";
    
    @Override
    public void accept(CloudEvent event) throws InvalidProtocolBufferException {
        if(event.getData() == null) {
            LOG.warning("No data found in cloud event payload!");
            return;
        }
        
        String cloudEventData = new String(event.getData().toBytes(), StandardCharsets.UTF_8);
        
        JsonObject jsonObject = JsonParser.parseString(cloudEventData).getAsJsonObject();
        JsonObject payload = jsonObject.getAsJsonObject("payload");
        
        String currentState = payload.get("currentState").getAsString();
        
        if("JOB_STATE_DONE".equalsIgnoreCase(currentState)) {
            
            var engToggle = System.getenv("ENG_TOGGLE");
            var projectId = System.getenv("PROJ_ID");
            var bigQueryTable = System.getenv("BIGQUERY_TABLE");
            var azureAccountName = System.getenv("AZURE_ACCT");
            var azureContainerName = System.getenv("AZURE_CNTR");
            var azureFileName = System.getenv("AZURE_FILE");
            var secretKey = System.getenv("SECRET_KEY");
            var mdnTempBucket = System.getenv("TEMP_BUCKET");
            var mdnFileBucket = System.getenv("FILE_BUCKET");
            
            Storage storage = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
            
            String zipFileName = createFileName();
            
            Page<Blob> blobs = storage.list(mdnTempBucket);
            List<String> tempFileNames = new ArrayList<>();
            List<BlobId> blobIds = new ArrayList<>();
            
            for (Blob blob : blobs.iterateAll()) {
                tempFileNames.add(blob.getName());
                blobIds.add(blob.getBlobId());
            }
            
            Storage.ComposeRequest composeRequest = Storage.ComposeRequest.newBuilder()
                    .addSource(tempFileNames)
                    .setTarget(BlobInfo.newBuilder(mdnTempBucket, zipFileName).build())
                    .build();
            
            Blob tempZip11Blolb = storage.compose(composeRequest);
            
            CopyWriter zip11CopyWriter = tempZip11Blolb.copyTo(mdnFileBucket);
            
            blobIds.add(tempZip11Blolb.getBlobId());
            storage.delete(blobIds);
            
            Blob zip11Blob = zip11CopyWriter.getResult();
                
            long fileSize = zip11Blob.getSize();
            String fileData = new String (zip11Blob.getContent());
            
            if(!Boolean.parseBoolean(engToggle)) {
                LOG.warning("Engineering Feed Toggled Off.");
                insertRecordIntoBigQuery(projectId, bigQueryTable, zipFileName, fileSize, FAILURE, TOGGLE_ERROR_MESSAGE);
                return;
            }
            
            String secretValue = "";
            
            try {
                secretValue = Files.readString(Paths.get("/eng/azure/key/" + secretKey));
            } catch (IOException e) {
                LOG.warning("Failed To Retrieve Secret" + e.getMessage());
            }
            
            BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
                    .endpoint("https://" + azureAccountName + ".blob.core.windows.net/")
                    .sasToken(secretValue)
                    .buildClient();
            
            BlobContainerClient containerClient = blobServiceClient
                    .getBlobContainerClient(azureContainerName);
            uploadBlobFromFile(containerClient, zipFileName, fileData, fileSize, projectId, bigQueryTable, azureFileName);
   //         uploadBlobFromFileTwo(containerClient, zipFileName, zip11Blob, fileSize, projectId, bigQueryTable, azureFileName);
        }
    }
    
    private void uploadBlobFromFile(BlobContainerClient blobContainerClient, String fileName, String fileData, long fileSize, String projectId, String bigQueryTable, String azureFileName) {
        BlobClient blobClient = blobContainerClient.getBlobClient(azureFileName);
        
        try {
            blobClient.upload(BinaryData.fromString(fileData), true);
            insertRecordIntoBigQuery(projectId, bigQueryTable, fileName, fileSize, SUCCESS, DEFAULT);
            
            LOG.info("SUCCESSFUL UPLOAD");
        } catch (UncheckedIOException ex) {
            LOG.warning("Failed To Upload To Azure: " + ex.getMessage());
            insertRecordIntoBigQuery(projectId, bigQueryTable, fileName, fileSize, FAILURE, UPLOAD_ERROR_MESSAGE);
        }
    }
    
    private void uploadBlobFromFileTwo(BlobContainerClient blobContainerClient, String fileName, Blob fileData, long fileSize, String projectId, String bigQueryTable, String azureFileName) {
        
        BlockBlobClient blockBlobClient = blobContainerClient.getBlobClient(azureFileName).getBlockBlobClient();
        try (ByteArrayInputStream dataStream = new ByteArrayInputStream(fileData.getContent())) {
            blockBlobClient.upload(dataStream, fileData.getSize(), true);
            insertRecordIntoBigQuery(projectId, bigQueryTable, fileName, fileSize, SUCCESS, DEFAULT);
            
            LOG.info("SUCCESSFUL STREAM UPLOAD");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void insertRecordIntoBigQuery(String projectId, String bigQueryTable, String fileName, long fileSize, String status, String errorMessage) {
        String endTime = DATETIME_FORMATTER.format(LocalDateTime.now());
        String startTimeStr = DATETIME_FORMATTER.format(startTime);
        
        String sqlTransactionDate = "PARSE_DATE('%m-%d-%Y', '" + transactionDate + "')";
        String sqlStartTime = "PARSE_TIMESTAMP('%m-%d-%Y %R:%S', '" + startTimeStr + "')";
        String sqlEndTime = "PARSE_TIMESTAMP('%m-%d-%Y %R:%S', '" + endTime + "')";
        
        String tableId = projectId + "." + bigQueryTable;
        String tableRows = "(transaction_date, file_name, file_size, zip11_count, start_time, end_time, status, error_message) ";
        String rowValue = sqlTransactionDate + ", '" + fileName + "', " + "' "+ fileSize + "', DEFAULT, " + sqlStartTime + ", " + sqlEndTime +", '" + status + "', " + errorMessage;
        
        try {
            
            BigQuery bigquery = BigQueryOptions.newBuilder().setProjectId(projectId).build().getService();
            
            String query = "INSERT `" + tableId + "` " + tableRows + "VALUES (" + rowValue + ");";
            
            QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).build();
            
            Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).build());
            queryJob = queryJob.waitFor();
            
            if (queryJob == null) {
                throw new Exception("Job No Longer Exists");
            }
            
            if (queryJob.getStatus().getError() != null) {
                throw new Exception(queryJob.getStatus().getError().toString());
            }
            
            queryJob.getQueryResults();
        } catch (Exception e) {
            LOG.warning("Failed to Insert To BigQuery: " + e);
        }
    }
    
    private static String createFileName() {
        return "MDN_ZIP11_" + startTime.format(FILE_DATETIME_FORMATTER) + ".csv";
    }
}
