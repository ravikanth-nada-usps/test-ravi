package com.function;


import com.google.cloud.firestore.Firestore;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import com.google.cloud.ServiceOptions;


import java.io.IOException;
import java.time.Duration;

public class FirestoreConnection {

    private static volatile Firestore firestoreInstance;

    private static Firestore initialize() throws IOException {
        if (firestoreInstance != null) {
            return firestoreInstance;
        }

        var databaseId = System.getenv("database");

        FirestoreOptions firestoreOptions = FirestoreOptions.getDefaultInstance().toBuilder()
                .setCredentials(GoogleCredentials.getApplicationDefault())
                .setDatabaseId(databaseId)
                .build();


        return firestoreOptions.getService();
    }

    public static Firestore getFirestore() throws IOException {
        // local variable to avoid several reads of volatile member variable
        Firestore instance = firestoreInstance;

        if (instance == null) {
            synchronized (FirestoreConnection.class) {
                instance = firestoreInstance;
                // make sure pool instance hasn't been created since waiting for lock
                if (instance == null) {
                    firestoreInstance = initialize();
                    instance = firestoreInstance;
                }
            }
        }

        return instance;
    }


}