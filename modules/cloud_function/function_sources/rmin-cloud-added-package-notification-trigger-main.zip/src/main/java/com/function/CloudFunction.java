package com.function;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.google.cloud.functions.CloudEventsFunction;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.events.cloud.firestore.v1.DocumentEventData;
import com.google.events.cloud.firestore.v1.Value;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.ByteString;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;


import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;

import io.cloudevents.CloudEvent;

public class CloudFunction implements CloudEventsFunction {
    private static final Logger logger = Logger.getLogger(CloudFunction.class.getName());
    private Firestore firestore;
    private Publisher emailPublisher;

    @Override
    public void accept(CloudEvent event) throws InvalidProtocolBufferException {

        try {
            firestore = FirestoreConnection.getFirestore();
            emailPublisher = PackageNotificationPubsub.getPubSub();
            var publishSmsMessage = Boolean.parseBoolean(System.getenv("publishSmsMessage"));

            DocumentEventData firestorEventData = DocumentEventData.parseFrom(event.getData().toBytes());

            if(!firestorEventData.getValue().toString().isBlank()) {

                //Getting the Id from the Name
                String principalId = firestorEventData.getValue().getName().split("/")[6];
                Map<String, Value> fields = firestorEventData.getValue().getFieldsMap();
                String primaryAddressIndicator = fields.get("primaryAddressIndicator").getStringValue();
                String impb = fields.get("impb").getStringValue();

                final DocumentReference subscriberDetails =  this.firestore
                        .collection(Constants.SUBSCRIBERS)
                        .document(principalId);

                ApiFuture<DocumentSnapshot> future = subscriberDetails.get();
                DocumentSnapshot document = future.get();
                if (document.exists()) {
                    HashMap<String,Object> physicalAddress = (((HashMap<String,Object>) document.getData().get(Constants.PHYSICALADDRESS)));
                    if(physicalAddress != null && !physicalAddress.isEmpty()){

                        if(primaryAddressIndicator.equals("1")) {

                            HashMap<String,Object> addressMap = ((HashMap<String,Object>) physicalAddress.get(Constants.PRIMARYADDRESS));

                            if(addressMap != null && !addressMap.isEmpty()){
                                logger.info("Primary Address Exists for User: " + principalId + ", for impb: " + impb);
                                if(NotificationNullCheck("isActive", addressMap).equals("1") ){


                                    try {

                                        JSONObject packageNotificationMsg = new JSONObject();

                                        packageNotificationMsg.put("zip11", NotificationNullCheck("zip11", addressMap));
                                        packageNotificationMsg.put("principalId", principalId);
                                        packageNotificationMsg.put("impb", impb);
                                        packageNotificationMsg.put("emailAFPEnabled", NotificationNullCheck("emailAFPEnabled", addressMap));
                                        packageNotificationMsg.put("emailDDUEnabled", NotificationNullCheck("emailDDUEnabled", addressMap));
                                        packageNotificationMsg.put("emailDEUEnabled", NotificationNullCheck("emailDEUEnabled", addressMap));
                                        packageNotificationMsg.put("emailEDUEnabled", NotificationNullCheck("emailEDUEnabled", addressMap));
                                        packageNotificationMsg.put("emailPDEnabled", NotificationNullCheck("emailPDEnabled", addressMap));
                                        packageNotificationMsg.put("emailPITEnabled", NotificationNullCheck("emailPITEnabled", addressMap));
                                        packageNotificationMsg.put("smsAFPEnabled", NotificationNullCheck("smsAFPEnabled", addressMap));
                                        packageNotificationMsg.put("smsDDUEnabled", NotificationNullCheck("smsDDUEnabled", addressMap));
                                        packageNotificationMsg.put("smsDEUEnabled", NotificationNullCheck("smsDEUEnabled", addressMap));
                                        packageNotificationMsg.put("smsEDUEnabled", NotificationNullCheck("smsEDUEnabled", addressMap));
                                        packageNotificationMsg.put("smsPDEnabled", NotificationNullCheck("smsPDEnabled", addressMap));
                                        packageNotificationMsg.put("smsPITEnabled", NotificationNullCheck("smsPITEnabled", addressMap));
                                        packageNotificationMsg.put("packageEmail", NotificationNullCheck("packageNotificationEmail", addressMap));
                                        packageNotificationMsg.put("packagePhone", NotificationNullCheck("packageNotificationPhone", addressMap));

                                        logger.info("Package Notification Message Published, IMPB: " + fields.get("impb").getStringValue());

                                        PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
                                                .setData(ByteString.copyFromUtf8(packageNotificationMsg.toString()))
                                                .build();
                                        emailPublisher.publish(pubsubMessage);

                                        if(publishSmsMessage){
                                            Publisher smsPublisher = PackageSmsNotificationPubSub.getPubSub();
                                            smsPublisher.publish(pubsubMessage);
                                        }

                                    } catch(Exception e) {
                                        String message = new StringBuilder().append("Error Publishing Messages to the Topic: ")
                                                .append("Exception: ")
                                                .append(ExceptionUtils.getStackTrace(e))
                                                .toString();

                                        logger.log(Level.INFO, message);
                                    }
                                } else {
                                    logger.info("isActive is 0 for subscriber, " + principalId);

                                }

                            } else {
                                logger.info("Primary Address Does not exist for Subscriber, " + principalId);

                            }
                        } else {
                            logger.info("Primary Address Indicator was invalid for impb: " + impb);
                        }

                    } else {
                        logger.info("physicalAddress Does not exist in Subscriber with principalId: " + principalId);

                    }

                } else {
                    logger.info("Subscriber Does not exist in Firestore: " + principalId);

                }

            }

        } catch(Exception e) {
            String message = new StringBuilder().append("Error: ")
                    .append("Exception: ")
                    .append(ExceptionUtils.getStackTrace(e))
                    .toString();

            logger.log(Level.INFO, message);
        }


    }

    public static Object NotificationNullCheck(String key, HashMap<String,Object> addressMap){
        if(key.equals("packageNotificationEmail") || key.equals("packageNotificationPhone")) {
            if(addressMap.get(key) == null || addressMap.get(key).equals("") || addressMap.get(key).equals("null")) {
                return "";
            } else {
                return addressMap.get(key);
            }
        } else {
            if(addressMap.get(key) == null || addressMap.get(key).equals("") || addressMap.get(key).equals("null")) {
                return "0";
            } else {
                return addressMap.get(key);
            }
        }
    }
}