package com.function;

import com.google.cloud.pubsub.v1.Publisher;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.Flow;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONObject;


public class PackageNotificationPubsub {

    private static volatile Publisher publisherInstance;

    private static Publisher initialize() throws IOException {
        if (publisherInstance != null) {
            return publisherInstance;
        }

        var projectId = System.getenv("projectId");
        var topicId = System.getenv("emailTopic");

        ProjectTopicName topicName = ProjectTopicName.newBuilder()
                .setProject(projectId)
                .setTopic(topicId)
                .build();

        return Publisher.newBuilder(topicName).build();
    }

    public static Publisher getPubSub() throws IOException {
        // local variable to avoid several reads of volatile member variable
        Publisher instance = publisherInstance;

        if (instance == null) {
            synchronized (PackageNotificationPubsub.class) {
                instance = publisherInstance;
                // make sure pool instance hasn't been created since waiting for lock
                if (instance == null) {
                    publisherInstance = initialize();
                    instance = publisherInstance;
                }
            }
        }

        return instance;
    }


}