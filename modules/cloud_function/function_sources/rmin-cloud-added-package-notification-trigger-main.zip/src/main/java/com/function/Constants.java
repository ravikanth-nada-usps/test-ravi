package com.function;

public final class Constants{
    private Constants () {}

    //Firestore document specific constants
    public static final String PRINCIPALIDS = "principalIds";
    public static final String SUBSCRIBERS = "subscribers";
    public static final String PHYSICALADDRESS = "physicalAddress";
    public static final String PRIMARYADDRESS = "primaryAddress";
    public static final String SECONDARYADDRESS = "secondaryAddress";



}