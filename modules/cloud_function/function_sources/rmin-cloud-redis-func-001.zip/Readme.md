#### Deployment Command DEV:

gcloud functions deploy rmin-package-campaign-cache-e-03d --runtime python39 --trigger-topic rmin-package-campaign-cache-e-03d --region us-east4 --vpc-connector projects/upscio-it-idc-9060-03d/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-flats-cache-e-003d --runtime python39 --trigger-topic rmin-redischeck-flats-cache-e-003d --region us-east4 --vpc-connector projects/uspscio-idc-9060-00-sandbox/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=10.100.1.28,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-e-003d --runtime python39 --trigger-topic rmin-redischeck-subscriber-e-003d --region us-east4 --vpc-connector projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.1.4,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-003d --runtime python39 --trigger-topic rmin-redischeck-subscriber-2-e-003d --region us-east4 --vpc-connector projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.1.36,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-saturation-data-cache-e-003d --runtime python39 --trigger-topic rmin-saturation-data-cache-e-003d --region us-east4 --vpc-connector projects/upscio-it-idc-9060-03d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.1.60,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-dnzip11s-cache-e-003d --runtime python39 --trigger-topic rmin-redischeck-dnzip11s-cache-e-003d --region us-east4 --vpc-connector projects/upscio-it-idc-9060-03d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

#### Deployment Command DEV 2: 

gcloud functions deploy rmin-package-campaign-cache-e-02d --runtime python39 --trigger-topic rmin-package-campaign-cache-e-02d --region us-east4 --vpc-connector projects/uspscio-idc-9060-02d/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-saturation-data-cache-e-02d --runtime python39 --trigger-topic rmin-saturation-data-cache-e-02d --region us-east4 --vpc-connector projects/uspscio-idc-9060-02d/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis

#### Deployment Command DEV 3:

gcloud functions deploy rmin-package-campaign-cache-e-00d --runtime python39 --trigger-topic rmin-package-campaign-cache-e-00d --region us-east4 --vpc-connector projects/uspscio-idc-9060-00-sandbox/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=10.41.160.68,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-flats-cache-e-00d --runtime python39 --trigger-topic rmin-redischeck-flats-cache-e-00d --region us-east4 --vpc-connector projects/uspscio-idc-9060-00-sandbox/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=10.41.160.76,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis--egress-settings=private-ranges-only

gcloud functions deploy rmin-saturation-data-cache-e-00d --runtime python39 --trigger-topic rmin-saturation-data-cache-e-00d --region us-east4 --vpc-connector projects/uspscio-idc-9060-00-sandbox/locations/us-east4/connectors/idc-dev-serverless-access --set-env-vars REDISHOST=10.41.160.84,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis

#### Deployment Commands MRI:

gcloud functions deploy rmin-redischeck-subscriber-e-001d --runtime python39 --trigger-topic rmin-redischeck-subscriber-e-001d --region us-east4 --vpc-connector projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.1.12,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-001d --runtime python39 --trigger-topic rmin-redischeck-subscriber-2-e-001d --region us-east4 --vpc-connector projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.1.100,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-campaign-e-001d --runtime python39 --trigger-topic rmin-redischeck-campaigns-e-001d --region us-east4 --vpc-connector projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=10.100.1.4,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-package-campaign-cache-e-001d --runtime python39 --trigger-topic rmin-package-campaign-cache-e-001d --region us-east4 --vpc-connector projects/uspscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-saturation-data-cache-e-001d --runtime python39 --trigger-topic rmin-saturation-data-cache-e-001d --region us-east4 --vpc-connector projects/upscio-idc-9060-01d/locations/us-east4/connectors/rmin-dev-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis

#### Deployment Command SIT: 
gcloud functions deploy rmin-redischeck-subscriber-e-001s --runtime python39 --trigger-topic  rmin-redischeck-subscriber-e-001s --region us-east4 --vpc-connector projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.12,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-001s --runtime python39 --trigger-topic rmin-redischeck-subscriber-2-e-001s --region us-east4 --vpc-connector projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.44,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-campaign-e-001s --runtime python39 --trigger-topic  rmin-redischeck-campaigns-e-001s --region us-east4 --vpc-connector projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.4,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-package-campaign-cache-e-001s --runtime python39 --trigger-topic rmin-package-campaign-cache-e-001s --region us-east4 --vpc-connector projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-flats-cache-e-001s --runtime python39 --trigger-topic rmin-redischeck-flats-cache-e-001s --region us-east4 --vpc-connector projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.52,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-saturation-data-cache-e-001s --runtime python39 --trigger-topic rmin-saturation-data-cache-e-001s --region us-east4 --vpc-connector projects/uspscio-idc-9060-01s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis

#### Deployment Command SIT2: 
#### NOTE: main.py and requirements.txt file need to be in the Cloud Storage in order for commands to work
gcloud functions deploy rmin-redischeck-campaign-e-002s --runtime python39 --trigger-topic rmin-redischeck-campaigns-e-002s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-02s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.20,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-e-002s --runtime python39 --trigger-topic rmin-redischeck-subscriber-e-002s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-02s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.28,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-package-campaign-cache-e-002s --runtime python39 --trigger-topic rmin-package-campaign-cache-e-002s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-02s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

#### Deployment Command SIT3:
gcloud functions deploy rmin-package-campaign-cache-e-00s --runtime python39 --trigger-topic rmin-package-campaign-cache-e-00s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-campaign-e-01s --runtime python39 --trigger-topic  rmin-redischeck-campaigns-e-01s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.4,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-e-01s --runtime python39 --trigger-topic  rmin-redischeck-subscriber-e-01s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.12,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-01s --runtime python39 --trigger-topic  rmin-redischeck-subscriber-2-e-01s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.44,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-flats-cache-e-01s --runtime python39 --trigger-topic  rmin-redischeck-flats-cache-e-01s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=10.100.1.52,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-saturation-data-cache-e-00s --runtime python39 --trigger-topic rmin-saturation-data-cache-e-00s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis

#### CAT1 Deployment Commands:
gcloud functions deploy rmin-redischeck-subscriber-e-000c --runtime python39 --trigger-topic rmin-redischeck-subscriber-e-000c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=10.100.1.12,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-000c --runtime python39 --trigger-topic rmin-redischeck-subscriber-2-e-000c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=<subscriber primary ip after redis is created>,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-campaign-e-000c --runtime python39 --trigger-topic rmin-redischeck-campaigns-e-000c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=10.100.1.4,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only
  
gcloud functions deploy rmin-package-campaign-cache-e-000c --runtime python39 --trigger-topic rmin-package-campaign-cache-e-000c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only 

gcloud functions deploy rmin-saturation-data-cache-e-000c --runtime python39 --trigger-topic rmin-saturation-data-cache-e-000c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

#### CAT2 Deployment Commands:
gcloud functions deploy rmin-redischeck-subscriber-e-001c --runtime python39 --trigger-topic rmin-redischeck-subscriber-e-001c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-01c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=10.100.1.54,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-001c --runtime python39 --trigger-topic rmin-redischeck-subscriber-2-e-001c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-01c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=10.100.1.70,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only  

gcloud functions deploy rmin-redischeck-campaign-e-001c --runtime python39 --trigger-topic rmin-redischeck-campaigns-e-001c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-01c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=10.100.1.22,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-package-campaign-cache-e-001c --runtime python39 --trigger-topic rmin-package-campaign-cache-e-001c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-01c/locations/us-east4/connectors/rmin-cat-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only
  
gcloud functions deploy rmin-saturation-data-cache-e-001c --runtime python39 --trigger-topic rmin-saturation-data-cache-e-001c --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-01c/locations/us-east4/connectors/rmin-cet-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis

#### PROD Deployment Commands:
gcloud functions deploy rmin-redischeck-subscriber-e-000p --runtime python39 --trigger-topic rmin-redischeck-subscriber-e-000p --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00p/locations/us-east4/connectors/rmin-prod-serverless-conn --set-env-vars REDISHOST=10.100.1.12,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-subscriber-2-e-000p --runtime python39 --trigger-topic rmin-redischeck-subscriber-2-e-000p --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00p/locations/us-east4/connectors/rmin-prod-serverless-conn --set-env-vars REDISHOST=<subscriber primary ip after redis is created>,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only

gcloud functions deploy rmin-redischeck-campaign-e-000p --runtime python39 --trigger-topic rmin-redischeck-campaigns-e-000p --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00p/locations/us-east4/connectors/rmin-prod-serverless-conn --set-env-vars REDISHOST=10.100.1.20,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only
  
gcloud functions deploy rmin-package-campaign-cache-e-000p --runtime python39 --trigger-topic rmin-package-campaign-cache-e-000p --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00p/locations/us-east4/connectors/rmin-prod-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis --egress-settings=private-ranges-only
  
gcloud functions deploy rmin-saturation-data-cache-e-000p --runtime python39 --trigger-topic rmin-saturation-data-cache-e-000p --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00p/locations/us-east4/connectors/rmin-prod-serverless-conn --set-env-vars REDISHOST=X.X.X.X,REDISPORT=6379 --ingress-settings=internal-only --entry-point=check_redis
