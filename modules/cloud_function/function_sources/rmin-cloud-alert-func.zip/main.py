import base64
import requests
import os
import json
import datetime
import time

cache = {}
DOMAIN_NAME = os.environ.get('DOMAIN_NAME')
FROM_EMAIL = os.environ.get('FROM_EMAIL')
TO_EMAIL = os.environ.get('TO_EMAIL')
API_KEY = os.environ.get('API_KEY')
CACHE_EXPIRY_TIME = 300


def process_alert(event, context):
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)
    pubsub_message = json.loads(pubsub_message)

    alert = message(pubsub_message)

    if alert.policy_name in cache:
        diff = time.time() - cache[alert.policy_name]
        if(diff <= CACHE_EXPIRY_TIME):
            print(
                f'Last email was sent for this policy {diff}s ago. No email will be sent.')
            return
        else:
            cache[alert.policy_name] = time.time()
    else:
        cache[alert.policy_name] = time.time()

    html_message = "<html><body><p>"

    html_message += f'Policy Name: {alert.policy_name}<br>'
    html_message += 'Incident URL: <a href="' + \
        alert.incident_url + '">Click Here</a><br>'
    html_message += f'Summary: {alert.summary}<br>'
    html_message += f'Project: {alert.project_id}<br>'
    html_message += f'Resource: {alert.resource}<br>'
    html_message += f'Resource Type: {alert.resource_type}<br>'
    html_message += f'Incident State: {alert.state}<br>'
    html_message += f'Started At: {alert.started_at}<br>'

    html_message += "</p></body></html>"
    print(html_message)

    response = requests.post(
        f"https://api.mailgun.net/v3/{DOMAIN_NAME}/messages",
        auth=("api", API_KEY),
        data={"from": f"GCP Custom Alerts {FROM_EMAIL}",
              "to": [TO_EMAIL],
              "subject": alert.policy_name,
              "html": html_message})
    print(response.status_code)
    if response.status_code != 200:
        raise Exception(f"Email Send failid via mailgun : {response}")


class message:
    def __init__(self, pubsub_message):
        self.policy_name = ''
        self.incident_url = ''
        self.summary = ''
        self.project_id = ''
        self.resource = ''
        self.resource_type = ''
        self.state = ''
        self.started_at = ''

        if "incident" in pubsub_message:

            if "policy_name" in pubsub_message["incident"]:
                self.policy_name = pubsub_message["incident"]["policy_name"]

            if "started_at" in pubsub_message["incident"]:
                started_at = pubsub_message["incident"]["started_at"]
                self.started_at = datetime.datetime.fromtimestamp(started_at, datetime.timezone.utc)

            if "url" in pubsub_message["incident"]:
                self.incident_url = pubsub_message["incident"]["url"]

            if "summary" in pubsub_message["incident"]:
                self.summary = pubsub_message["incident"]["summary"]

            if "scoping_project_id" in pubsub_message["incident"]:
                self.project_id = pubsub_message["incident"]["scoping_project_id"]

            if "resource_display_name" in pubsub_message["incident"]:
                self.resource = pubsub_message["incident"]["resource_display_name"]

            if "resource_type_display_name" in pubsub_message["incident"]:
                self.resource_type = pubsub_message["incident"]["resource_type_display_name"]

            if "state" in pubsub_message["incident"]:
                self.state = pubsub_message["incident"]["state"]
