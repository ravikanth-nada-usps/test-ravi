# rmin-cloud-alert-func
A repository for the Cloud Alerting function.

### Dev Deploy Command
gcloud functions deploy send-email-alerts --entry-point process_alert --runtime python37 --trigger-topic log-alerts-test --region us-east4 --vpc-connector projects/uspscio-idc-9060-00-sandbox/locations/us-east4/connectors/idc-dev-serverless-access --ingress-settings=internal-only --set-secrets 'API_KEY=projects/28299036685/secrets/idc-dev-mailgun-key:1' --set-env-vars 'TO_EMAIL=rahul.gupta@usps.gov,FROM_EMAIL=USPSInformeddelivery@dev.informeddelivery.usps.com,DOMAIN_NAME=dev.informeddelivery.usps.com' --max-instances 1



### SIT Deploy Command
gcloud functions deploy rmin-alerts-e-01 --entry-point process_alert --runtime python37 --trigger-topic rmin-alerts-topic-01s --region us-east4 --vpc-connector projects/uspscio-it-idc-9060-00s/locations/us-east4/connectors/rmin-sit-serverless-conn --service-account=sit-email-notifications@uspscio-it-idc-9060-00s.iam.gserviceaccount.com --ingress-settings=internal-only --set-secrets 'API_KEY=projects/484155584924/secrets/mail-gun-key:2' --set-env-vars 'TO_EMAIL=rahul.gupta@usps.gov,FROM_EMAIL=USPSInformeddelivery@sit.informeddelivery.usps.com,DOMAIN_NAME=sit.informeddelivery.usps.com' --max-instances 1