const { Pool } = require('pg');
const fs = require('fs');
const dbpwd = fs.readFileSync('/etc/secrets/cloudsql/'+process.env.DB_KEY);
// Configuration for the PostgreSQL connection
const dbConfig = {
  user: process.env.DB_USER,
  password: dbpwd.toString(),
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
};

// Cloud Function entry point
exports.triggerPostgresCommand = async (req, res) => {
  const pool = new Pool(dbConfig);

  try {
    // Connect to the database
    const client = await pool.connect();
    console.info('Running... select partman.run_maintenance()');
    // Execute the SQL command
    const query = 'select partman.run_maintenance()';
    const result =  await client.query(query);

    // Release the database connection
    client.release();
    console.info('Completed run_maintenance command');
    res.status(200).send(result.rows);
  } catch (error) {
    console.error('Error executing SQL command:', error);
    res.status(500).send('Error executing SQL command.');
  } finally {
    // Close the database connection pool
    pool.end();
  }
};