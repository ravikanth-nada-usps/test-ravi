from cloudevents.http import CloudEvent
import functions_framework
from google.events.cloud import firestore
import os
import google.cloud.logging
import re
import logging
from google.cloud.pubsub import PublisherClient
from constants import constants as c

from helpers import redis_helpers
from helpers import pub_sub_helpers
from helpers import firestore_helpers

my_usps_toggle = os.environ.get('PROCESS_MY_USPS_FIELDS', False)
apigee_hybrid_toggle = os.environ.get('APIGEE_HYBRID_TOGGLE', False)

publisher_client = PublisherClient()
account_revision_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), os.environ.get('ACCOUNT_REVISION_TOPIC'))
physical_address_revision_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), os.environ.get('PHYSICAL_ADDRESS_REVISION_TOPIC'))

package_notification_topic = os.environ.get('PACKAGE_NOTIFICATION_TOPIC', '')
subscriber_opt_in_topic = os.environ.get('SUBSCRIBER_OPT_IN_TOPIC', '')

logger = google.cloud.logging.Client()
logger.setup_logging()

@functions_framework.cloud_event
def process_subscriber_change(cloud_event: CloudEvent) -> None:
    """Triggers by a change to a Firestore document.
    Args:
        cloud_event: cloud event with information on the firestore event trigger
    """
    firestore_payload = firestore.DocumentEventData()
    firestore_payload._pb.ParseFromString(cloud_event.data)

    if firestore_payload.value.create_time is None:
        logging.info("Document deleted by TTL policy, skipping Redis updates...")

    elif firestore_payload.old_value.create_time is None:
        logging_message = process_document_creation(firestore_payload)
        logging.info(logging_message)

    elif firestore_payload.old_value.create_time is not None and firestore_payload.value.create_time is not None:
        logging_message = process_document_updates(firestore_payload)
        logging.info(logging_message)


def process_document_creation(firestore_payload):
    messages = []

    principal_id = get_principal_id(firestore_payload.value.name)

    account = firestore_helpers.map_account_to_dict(firestore_payload.value)
    primary_address = firestore_helpers.map_pa_to_dict(firestore_payload.value, c.FirestoreContants.PHYSICAL_ADDRESS.value, c.FirestoreContants.PRIMARY_ADDRESS.value)
    secondary_address = firestore_helpers.map_pa_to_dict(firestore_payload.value, c.FirestoreContants.PHYSICAL_ADDRESS.value, c.FirestoreContants.SECONDARY_ADDRESS.value)

    # Only do redis work if the account is active, prevents MyUSPS events from updating the cache
    if "1" == account.get(c.DictConstants.IS_ACTIVE.value):

        # Create subscriber cache records for primary and secondary addresses
        if primary_address is not None and '1' == primary_address.get(c.DictConstants.IS_ACTIVE.value):
            redis_helpers.update_subscriber_cache(primary_address.get(c.DictConstants.ZIP11.value), principal_id, redis_helpers.create_subscriber_cache_value(account,primary_address))
            messages.append(f"created new subscriber cache record for {principal_id} and primary zip11 {primary_address.get(c.DictConstants.ZIP11.value)}")
        if secondary_address is not None and '1' == secondary_address.get(c.DictConstants.IS_ACTIVE.value):
            redis_helpers.update_subscriber_cache(secondary_address.get(c.DictConstants.ZIP11.value), principal_id, redis_helpers.create_subscriber_cache_value(account,secondary_address))
            messages.append(f"created new subscriber cache record for {principal_id} and secondary zip11 {secondary_address.get(c.DictConstants.ZIP11.value)}")

        # Create subscriber email cache records for primary and secondary addresses
        zip11_list = redis_helpers.create_email_cache_value(primary_address, secondary_address)
        if len(zip11_list) != 0:
            redis_helpers.update_subscriber_email_cache(account.get(c.DictConstants.EMAIL_ADDRESS.value), redis_helpers.create_email_cache_value(primary_address, secondary_address), principal_id)
            messages.append(f"created new subscriber email cache record for {principal_id} and email {account.get(c.DictConstants.EMAIL_ADDRESS.value)}")

    else:
        messages.append(f"skipped cache updates for {principal_id} because it was not active")

    # Generate the Pub/Sub Revision records and write them out to the appropriate topic
    account_revision_message = pub_sub_helpers.generate_account_revision_message(account, None, principal_id)
    primary_address_revision_message = pub_sub_helpers.generate_physical_address_revision_message(primary_address, None, principal_id)
    secondary_address_revision_message = pub_sub_helpers.generate_physical_address_revision_message(secondary_address, None, principal_id)
    primary_notification_settings_message = pub_sub_helpers.generate_package_notification_settings_message(primary_address, principal_id)
    secondary_notification_settings_message = pub_sub_helpers.generate_package_notification_settings_message(secondary_address, principal_id)

    account_msg_id = pub_sub_helpers.write_to_pubsub(account_revision_message, publisher_client, account_revision_topic_path)
    messages.append(f"wrote out account revision records for {principal_id} with id {account_msg_id}")

    if primary_address_revision_message is not None:
        primary_msg_id = pub_sub_helpers.write_to_pubsub(primary_address_revision_message, publisher_client, physical_address_revision_topic_path)
        messages.append(f"wrote out primary physical address records for zip11 {primary_address.get(c.DictConstants.ZIP11.value)} with id {primary_msg_id}")

    if secondary_address_revision_message is not None:
        secondary_msg_id = pub_sub_helpers.write_to_pubsub(secondary_address_revision_message, publisher_client, physical_address_revision_topic_path)
        messages.append(f"wrote out secondary physical address records for zip11 {secondary_address.get(c.DictConstants.ZIP11.value)} with id {secondary_msg_id}")

    if my_usps_toggle and primary_address is not None and package_notification_topic != '' and primary_notification_settings_message is not None:
        package_notification_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), package_notification_topic)
        primary_notifications_msg_id = pub_sub_helpers.write_to_pubsub(primary_notification_settings_message, publisher_client, package_notification_topic_path)
        messages.append(f"wrote out primary physical address notification settings for zip11 {primary_address.get(c.DictConstants.ZIP11.value)} with id {primary_notifications_msg_id}")

    if my_usps_toggle and secondary_address is not None and package_notification_topic != '' and secondary_notification_settings_message is not None:
        package_notification_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), package_notification_topic)
        secondary_notifications_msg_id = pub_sub_helpers.write_to_pubsub(secondary_notification_settings_message, publisher_client, package_notification_topic_path)
        messages.append(f"wrote out secondary physical address notification settings for zip11 {secondary_address.get(c.DictConstants.ZIP11.value)} with id {secondary_notifications_msg_id}")

    return ', \n'.join(messages)


def process_document_updates(firestore_payload):
    messages = []

    principal_id = get_principal_id(firestore_payload.value.name)

    # Map Firestore values into dicts
    account = firestore_helpers.map_account_to_dict(firestore_payload.value)
    account_old = firestore_helpers.map_account_to_dict(firestore_payload.old_value)
    primary_address = firestore_helpers.map_pa_to_dict(firestore_payload.value, c.FirestoreContants.PHYSICAL_ADDRESS.value, c.FirestoreContants.PRIMARY_ADDRESS.value)
    primary_address_old = firestore_helpers.map_pa_to_dict(firestore_payload.old_value, c.FirestoreContants.PHYSICAL_ADDRESS.value, c.FirestoreContants.PRIMARY_ADDRESS.value)
    secondary_address = firestore_helpers.map_pa_to_dict(firestore_payload.value, c.FirestoreContants.PHYSICAL_ADDRESS.value, c.FirestoreContants.SECONDARY_ADDRESS.value)
    secondary_address_old = firestore_helpers.map_pa_to_dict(firestore_payload.old_value, c.FirestoreContants.PHYSICAL_ADDRESS.value, c.FirestoreContants.SECONDARY_ADDRESS.value)

    # Determine what kind of subscriber update this was and update the cache accordingly
    if primary_address is not None and primary_address_old is not None and '0' != primary_address.get(c.DictConstants.IS_ACTIVE.value) and primary_address.get(c.DictConstants.ZIP11.value) != primary_address_old.get(c.DictConstants.ZIP11.value):
        redis_helpers.delete_subscriber_cache(primary_address_old.get(c.DictConstants.ZIP11.value), principal_id)
        redis_helpers.update_subscriber_cache(primary_address.get(c.DictConstants.ZIP11.value), principal_id, redis_helpers.create_subscriber_cache_value(account,primary_address))
        messages.append(f"deleted subscriber cache record for {principal_id} and primary zip11 {primary_address_old.get(c.DictConstants.ZIP11.value)} and created new one for {primary_address.get(c.DictConstants.ZIP11.value)}")

    elif should_delete_from_subscriber_cache(primary_address, primary_address_old):
        redis_helpers.delete_subscriber_cache(primary_address.get(c.DictConstants.ZIP11.value), principal_id)
        messages.append(f"deleted subscriber cache record for {principal_id} and primary zip11 {primary_address.get(c.DictConstants.ZIP11.value)}")

    elif should_update_subscriber_cache(account, account_old, primary_address, primary_address_old):
        redis_helpers.update_subscriber_cache(primary_address.get(c.DictConstants.ZIP11.value), principal_id, redis_helpers.create_subscriber_cache_value(account,primary_address))
        messages.append(f"updated subscriber cache record for {principal_id} and primary zip11 {primary_address.get(c.DictConstants.ZIP11.value)}")

    else:
        messages.append("condition not met for primary address for subscriber cache update")

    if secondary_address is not None and secondary_address_old is not None and '0' != secondary_address.get(c.DictConstants.IS_ACTIVE.value) and secondary_address.get(c.DictConstants.ZIP11.value) != secondary_address_old.get(c.DictConstants.ZIP11.value):
        redis_helpers.delete_subscriber_cache(secondary_address_old.get(c.DictConstants.ZIP11.value), principal_id)
        redis_helpers.update_subscriber_cache(secondary_address.get(c.DictConstants.ZIP11.value), principal_id, redis_helpers.create_subscriber_cache_value(account,secondary_address))
        messages.append(f"deleted subscriber cache record for {principal_id} and secondary zip11 {secondary_address_old.get(c.DictConstants.ZIP11.value)} and created new one for {secondary_address.get(c.DictConstants.ZIP11.value)}")

    elif should_delete_from_subscriber_cache(secondary_address, secondary_address_old):
        redis_helpers.delete_subscriber_cache(secondary_address.get(c.DictConstants.ZIP11.value), principal_id)
        messages.append(f"deleted subscriber cache record for {principal_id} and secondary zip11 {secondary_address.get(c.DictConstants.ZIP11.value)}")

    elif should_update_subscriber_cache(account, account_old, secondary_address, secondary_address_old):
        redis_helpers.update_subscriber_cache(secondary_address.get(c.DictConstants.ZIP11.value), principal_id, redis_helpers.create_subscriber_cache_value(account,secondary_address))
        messages.append(f"created new subscriber cache record for {principal_id} and secondary zip11 {secondary_address.get(c.DictConstants.ZIP11.value)}")

    else:
        messages.append("condition not met for secondary address for subscriber cache update")

    # Determine what kind of subscriber update this was and update the email
    if account.get(c.DictConstants.EMAIL_ADDRESS.value) != account_old.get(c.DictConstants.EMAIL_ADDRESS.value):
        redis_helpers.delete_subscriber_email_cache(account_old.get(c.DictConstants.EMAIL_ADDRESS.value), principal_id)
        redis_helpers.update_subscriber_email_cache(account.get(c.DictConstants.EMAIL_ADDRESS.value), redis_helpers.create_email_cache_value(primary_address, secondary_address),principal_id)
        messages.append(f"deleted email cache record for {principal_id} and email {account_old.get(c.DictConstants.EMAIL_ADDRESS.value)} and created new one for {account.get(c.DictConstants.EMAIL_ADDRESS.value)}")

    elif '1' == account_old.get(c.DictConstants.IS_ACTIVE.value) and '0' == account.get(c.DictConstants.IS_ACTIVE.value):
        redis_helpers.delete_subscriber_email_cache(account.get(c.DictConstants.EMAIL_ADDRESS.value), principal_id)
        messages.append(f"deleted email cache record for deactivated account {principal_id} and email {account.get(c.DictConstants.EMAIL_ADDRESS.value)}")

    elif should_update_email_cache(primary_address_old, primary_address, secondary_address_old, secondary_address):
        redis_helpers.update_subscriber_email_cache(account.get(c.DictConstants.EMAIL_ADDRESS.value), redis_helpers.create_email_cache_value(primary_address, secondary_address), principal_id)
        messages.append(f"updated email cache record for {principal_id} and email {account.get(c.DictConstants.EMAIL_ADDRESS.value)}")

    else:
        messages.append(f"condition not met for subscriber email cache update")

    # Generate the Pub/Sub Revision records and write them out to the appropriate topic
    account_revision_message = pub_sub_helpers.generate_account_revision_message(account, account_old, principal_id)
    primary_address_revision_message = pub_sub_helpers.generate_physical_address_revision_message(primary_address, primary_address_old, principal_id)
    secondary_address_revision_message = pub_sub_helpers.generate_physical_address_revision_message(secondary_address, secondary_address_old, principal_id)
    primary_notification_settings_message = pub_sub_helpers.generate_package_notification_settings_message(primary_address, principal_id)
    secondary_notification_settings_message = pub_sub_helpers.generate_package_notification_settings_message(secondary_address, principal_id)

    account_msg_id = pub_sub_helpers.write_to_pubsub(account_revision_message, publisher_client, account_revision_topic_path)
    messages.append(f"wrote out account revision records for {principal_id} with id {account_msg_id}")

    if primary_address_revision_message is not None:
        primary_msg_id = pub_sub_helpers.write_to_pubsub(primary_address_revision_message, publisher_client, physical_address_revision_topic_path)
        messages.append(f"wrote out primary physical address records for zip11 {primary_address.get(c.DictConstants.ZIP11.value)} with id {primary_msg_id}")

    if secondary_address_revision_message is not None:
        secondary_msg_id = pub_sub_helpers.write_to_pubsub(secondary_address_revision_message, publisher_client, physical_address_revision_topic_path)
        messages.append(f"wrote out secondary physical address records for zip11 {secondary_address.get(c.DictConstants.ZIP11.value)} with id {secondary_msg_id}")

    if my_usps_toggle and primary_address is not None and package_notification_topic != '' and is_notification_update(primary_address, primary_address_old) and primary_notification_settings_message is not None:
        package_notification_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), package_notification_topic)
        primary_notifications_msg_id = pub_sub_helpers.write_to_pubsub(primary_notification_settings_message, publisher_client, package_notification_topic_path)
        messages.append(f"wrote out primary physical address notification settings for zip11 {primary_address.get(c.DictConstants.ZIP11.value)} with id {primary_notifications_msg_id}")

    if my_usps_toggle and secondary_address is not None and package_notification_topic != '' and is_notification_update(secondary_address, secondary_address_old) and secondary_notification_settings_message is not None:
        package_notification_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), package_notification_topic)
        secondary_notifications_msg_id = pub_sub_helpers.write_to_pubsub(secondary_notification_settings_message, publisher_client, package_notification_topic_path)
        messages.append(f"wrote out secondary physical address notification settings for zip11 {secondary_address.get(c.DictConstants.ZIP11.value)} with id {secondary_notifications_msg_id}")

    if apigee_hybrid_toggle and primary_address is not None and primary_address_old is not None and primary_address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value) != '' and primary_address_old.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value) == '':
        subscriber_opt_in_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), subscriber_opt_in_topic)
        subscriber_opt_in_settings_message = pub_sub_helpers.generate_subscriber_opt_in_settings_message(primary_address)
        primary_opt_in_settings_msg_id = pub_sub_helpers.write_to_pubsub(subscriber_opt_in_settings_message, publisher_client, subscriber_opt_in_topic_path)
        messages.append(f"wrote out primary address opt in settings for physical address id {primary_address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value)} with id {primary_opt_in_settings_msg_id}")

    if apigee_hybrid_toggle and secondary_address is not None and secondary_address_old is not None and secondary_address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value) != '' and secondary_address_old.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value) == '':
        subscriber_opt_in_topic_path = publisher_client.topic_path(os.environ.get('PROJECT_ID', ''), subscriber_opt_in_topic)
        subscriber_opt_in_settings_message = pub_sub_helpers.generate_subscriber_opt_in_settings_message(secondary_address)
        secondary_opt_in_settings_msg_id = pub_sub_helpers.write_to_pubsub(subscriber_opt_in_settings_message, publisher_client, subscriber_opt_in_topic_path)
        messages.append(f"wrote out secondary address opt in settings for physical address id {secondary_address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value)} with id {secondary_opt_in_settings_msg_id}")

    return ', \n'.join(messages)

def get_principal_id(document_path):
    return re.search('[^\\/](\\d)*$', document_path).group()


def should_update_email_cache(primary_address_old, primary_address, secondary_address_old, secondary_address):
    return (primary_address_old is None and primary_address is not None) or \
        (primary_address_old is not None and primary_address is not None and primary_address.get(c.DictConstants.ZIP11.value) != primary_address_old.get(c.DictConstants.ZIP11.value)) or \
        (secondary_address_old is None and secondary_address is not None) or \
        (secondary_address_old is not None and secondary_address is not None and secondary_address.get(c.DictConstants.ZIP11.value) != secondary_address_old.get(c.DictConstants.ZIP11.value) or \
         (primary_address_old is not None and primary_address is not None and  primary_address_old.get(c.DictConstants.IS_ACTIVE.value) != primary_address.get(c.DictConstants.IS_ACTIVE.value)) or \
         (secondary_address_old is not None and secondary_address is not None and secondary_address_old.get(c.DictConstants.IS_ACTIVE.value) != secondary_address.get(c.DictConstants.IS_ACTIVE.value)))

def should_update_subscriber_cache(account, account_old, address, address_old):

    if address is not None and '0' == address.get(c.DictConstants.IS_ACTIVE.value):
        return False
    else:
        return (address is not None and '1' == address.get(c.DictConstants.IS_ACTIVE.value)) and \
            (address_old is None) or \
            ((address_old is not None) and
             ((account_old.get(c.DictConstants.IS_ACTIVE.value) == '0' and account.get(c.DictConstants.IS_ACTIVE.value) == '1') or
              (account_old.get(c.DictConstants.ACCOUNT_ID.value) != account.get(c.DictConstants.ACCOUNT_ID.value)) or
              (account_old.get(c.DictConstants.EMAIL_ADDRESS.value) != account.get(c.DictConstants.EMAIL_ADDRESS.value)) or
              (account_old.get(c.DictConstants.UNSUBSCRIBE_TOKEN.value) != account.get(c.DictConstants.UNSUBSCRIBE_TOKEN.value)) or
              (account_old.get(c.DictConstants.FIRST_NAME.value) != account.get(c.DictConstants.FIRST_NAME.value)) or
              (address_old.get(c.DictConstants.PRIMARY_ADDRESS_IND.value) != address.get(c.DictConstants.PRIMARY_ADDRESS_IND.value)) or
              (address_old.get(c.DictConstants.DN_OPT_IN.value) != address.get(c.DictConstants.DN_OPT_IN.value)) or
              (address_old.get(c.DictConstants.DIGEST_OPT_IN.value) != address.get(c.DictConstants.DIGEST_OPT_IN.value)) or
              (address_old.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value) != address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value)) or
              (address_old.get(c.DictConstants.ZIP11.value) != address.get(c.DictConstants.ZIP11.value)))) or \
            is_notification_update(address, address_old)


def should_delete_from_subscriber_cache(address, address_old):
    return address_old is not None and '1' == address_old.get(c.DictConstants.IS_ACTIVE.value) and \
        address is not None and '0' == address.get(c.DictConstants.IS_ACTIVE.value)

def is_notification_update(address, address_old):
    return address is not None and address_old is None or \
        (address_old is not None and
         (address_old.get(c.DictConstants.PACKAGE_NUMBER.value) != address.get(c.DictConstants.PACKAGE_NUMBER.value) or
          address_old.get(c.DictConstants.PACKAGE_EMAIL.value) != address.get(c.DictConstants.PACKAGE_EMAIL.value) or
          address_old.get(c.DictConstants.EMAIL_AFP_ENABLED.value) != address.get(c.DictConstants.EMAIL_AFP_ENABLED.value) or
          address_old.get(c.DictConstants.EMAIL_DDU_ENABLED.value) != address.get(c.DictConstants.EMAIL_DDU_ENABLED.value) or
          address_old.get(c.DictConstants.EMAIL_DEU_ENABLED.value) != address.get(c.DictConstants.EMAIL_DEU_ENABLED.value) or
          address_old.get(c.DictConstants.EMAIL_EDU_ENABLED.value) != address.get(c.DictConstants.EMAIL_EDU_ENABLED.value) or
          address_old.get(c.DictConstants.EMAIL_PD_ENABLED.value) != address.get(c.DictConstants.EMAIL_PD_ENABLED.value) or
          address_old.get(c.DictConstants.EMAIL_PIT_ENABLED.value) != address.get(c.DictConstants.EMAIL_PIT_ENABLED.value) or
          address_old.get(c.DictConstants.SMS_AFP_ENABLED.value) != address.get(c.DictConstants.SMS_AFP_ENABLED.value) or
          address_old.get(c.DictConstants.SMS_DDU_ENABLED.value) != address.get(c.DictConstants.SMS_DDU_ENABLED.value) or
          address_old.get(c.DictConstants.SMS_DEU_ENABLED.value) != address.get(c.DictConstants.SMS_DEU_ENABLED.value) or
          address_old.get(c.DictConstants.SMS_EDU_ENABLED.value) != address.get(c.DictConstants.SMS_EDU_ENABLED.value) or
          address_old.get(c.DictConstants.SMS_PD_ENABLED.value) != address.get(c.DictConstants.SMS_PD_ENABLED.value) or
          address_old.get(c.DictConstants.SMS_PIT_ENABLED.value) != address.get(c.DictConstants.SMS_PIT_ENABLED.value)))