from datetime import datetime
from zoneinfo import ZoneInfo


def generate_bq_timestamp():
    return datetime.now(ZoneInfo("UTC")).strftime("%Y-%m-%dT%H:%M:%S.%f")


def convert_firestore_timestamp(timestamp):
    return datetime.fromtimestamp(timestamp.timestamp(), ZoneInfo("UTC")).strftime("%Y-%m-%dT%H:%M:%S.%f")

