import google.cloud.logging
import logging
from constants import constants as c

logger = google.cloud.logging.Client()
logger.setup_logging()


def map_account_to_dict(document):
    try:
        return {
            c.DictConstants.ACCOUNT_ID.value: document.fields[c.FirestoreContants.ACCOUNT_ID.value].string_value,
            c.DictConstants.ACCOUNT_TYPE.value: document.fields[c.FirestoreContants.ACCOUNT_TYPE.value].string_value,
            c.DictConstants.BANNER_OPT_OUT.value: document.fields[c.FirestoreContants.BANNER_OPT_OUT.value].string_value,
            c.DictConstants.BANNER_START_DATE.value: document.fields[c.FirestoreContants.BANNER_START_DATE.value].string_value,
            c.DictConstants.ESOF_PREFERRED_LOCATION.value: get_possible_missing_field(document, c.FirestoreContants.ESOF_PREFERRED_LOCATION.value),
            c.DictConstants.IS_ACTIVE.value: document.fields[c.FirestoreContants.IS_ACTIVE.value].string_value,
            c.DictConstants.EMAIL_ADDRESS.value: document.fields[c.FirestoreContants.EMAIL_ADDRESS.value].string_value,
            c.DictConstants.FIRST_NAME.value: document.fields[c.FirestoreContants.FIRST_NAME.value].string_value,
            c.DictConstants.UNSUBSCRIBE_TOKEN.value: document.fields[c.FirestoreContants.UNSUBSCRIBE_TOKEN.value].string_value
            }
    except Exception as e:
        logging.exception('Failed to parse document into account', e)
        raise e


def map_pa_to_dict(document, pa_key, address_key):
    try:
        return {
            c.DictConstants.ZIP11.value: document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.ZIP11.value].string_value,
            c.DictConstants.COA_PENDING.value: document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.COA_PENDING.value].string_value,
            c.DictConstants.DN_OPT_IN.value: document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.DN_OPT_IN.value].string_value,
            c.DictConstants.DIGEST_OPT_IN.value: document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.DIGEST_OPT_IN.value].string_value,
            c.DictConstants.IS_ACTIVE.value: document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.IS_ACTIVE.value].string_value,
            c.DictConstants.PACKAGE_EMAIL.value: document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.PACKAGE_NOTIFICATION_EMAIL.value].string_value,
            c.DictConstants.PACKAGE_NUMBER.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.PACKAGE_NOTIFICATION_PHONE.value].string_value,
            c.DictConstants.EMAIL_AFP_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.EMAIL_AFP_ENABLED.value].string_value,
            c.DictConstants.EMAIL_DDU_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.EMAIL_DDU_ENABLED.value].string_value,
            c.DictConstants.EMAIL_DEU_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.EMAIL_DEU_ENABLED.value].string_value,
            c.DictConstants.EMAIL_EDU_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.EMAIL_EDU_ENABLED.value].string_value,
            c.DictConstants.EMAIL_PD_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.EMAIL_PD_ENABLED.value].string_value,
            c.DictConstants.EMAIL_PIT_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.EMAIL_PIT_ENABLED.value].string_value,
            c.DictConstants.SMS_AFP_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.SMS_AFP_ENABLED.value].string_value,
            c.DictConstants.SMS_DDU_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.SMS_DDU_ENABLED.value].string_value,
            c.DictConstants.SMS_DEU_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.SMS_DEU_ENABLED.value].string_value,
            c.DictConstants.SMS_EDU_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.SMS_EDU_ENABLED.value].string_value,
            c.DictConstants.SMS_PD_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.SMS_PD_ENABLED.value].string_value,
            c.DictConstants.SMS_PIT_ENABLED.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.SMS_PIT_ENABLED.value].string_value,
            c.DictConstants.PHYSICAL_ADDRESS_ID.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.PHYSICAL_ADDRESS_ID.value].string_value,
            c.DictConstants.PRIMARY_ADDRESS_IND.value:document.fields[pa_key].map_value.fields[address_key].map_value.fields[c.FirestoreContants.PRIMARY_ADDRESS_IND.value].string_value
        }

    except Exception as e:
        logging.debug('Failed to parse document into physical address')
        return None

def get_possible_missing_field(document, field_name):
    try:
        return document.fields[field_name].string_value

    except Exception as e:
        return ''