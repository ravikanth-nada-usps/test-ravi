import redis
import os

subscriber_host = os.environ.get('SUBSCRIBERS_IP', '127.0.0.1')
subscriber_email_host = os.environ.get('SUBSCRIBERS_EMAIL_IP', '127.0.0.1')

class Singleton(type):
    """
    A metaclass for singleton purpose. Every singleton class should inherit from this class
    """
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class SubscriberClient(metaclass=Singleton):
    def __init__(self):
        self.pool = redis.ConnectionPool(host = subscriber_host, port = 6379)

    @property
    def conn(self):
        if not hasattr(self, '_conn'):
            self.getConnection()
        return self._conn

    def getConnection(self):
        self._conn = redis.Redis(connection_pool = self.pool)

class SubscriberEmailClient(metaclass=Singleton):
    def __init__(self):
        self.pool = redis.ConnectionPool(host = subscriber_email_host, port = 6379)

    @property
    def conn(self):
        if not hasattr(self, '_conn'):
            self.getConnection()
        return self._conn

    def getConnection(self):
        self._conn = redis.Redis(connection_pool = self.pool)