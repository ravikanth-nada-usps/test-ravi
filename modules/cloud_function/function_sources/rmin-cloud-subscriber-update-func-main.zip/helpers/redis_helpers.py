from retry import retry
import redis
import os
import json

from constants import constants as c
from helpers import RedisClient


@retry(tries=6, delay=5, backoff=2, max_delay=120)
def update_subscriber_cache(zip11, principal_id, cache_values):
    client = RedisClient.SubscriberClient()

    client.conn.hset(zip11[0:5], principal_id + "-" + zip11, cache_values)
    client.conn.sadd("s" + zip11, principal_id + "-" + zip11)


@retry(tries=6, delay=5, backoff=2, max_delay=120)
def delete_subscriber_cache(zip11, principal_id):
    client = RedisClient.SubscriberClient()

    client.conn.hdel(zip11[0:5], principal_id + "-" + zip11)
    client.conn.srem("s" + zip11, principal_id + "-" + zip11)


@retry(tries=6, delay=5, backoff=2, max_delay=120)
def update_subscriber_email_cache(email_address, zip11_list, principal_id):
    if len(zip11_list) != 0:
        client = RedisClient.SubscriberEmailClient()

        client.conn.hset(email_address, "pi:"+ principal_id, zip11_list)


@retry(tries=6, delay=5, backoff=2, max_delay=120)
def delete_subscriber_email_cache(email_address, principal_id):
    client = RedisClient.SubscriberEmailClient()

    client.conn.hdel(email_address, "pi:"+ principal_id)


def create_subscriber_cache_value(account, address):
    my_usps_toggle = os.environ.get('PROCESS_MY_USPS_FIELDS', False)

    if my_usps_toggle:
        document_values = {c.DictConstants.ACCOUNT_ID.value: account.get(c.DictConstants.ACCOUNT_ID.value),
                           c.DictConstants.EMAIL_ADDRESS.value: account.get(c.DictConstants.EMAIL_ADDRESS.value),
                           c.DictConstants.UNSUBSCRIBE_TOKEN.value: account.get(c.DictConstants.UNSUBSCRIBE_TOKEN.value),
                           c.DictConstants.FIRST_NAME.value: account.get(c.DictConstants.FIRST_NAME.value),
                           c.DictConstants.PRIMARY_ADDRESS_IND.value: address.get(c.DictConstants.PRIMARY_ADDRESS_IND.value),
                           c.DictConstants.DN_OPT_IN.value: address.get(c.DictConstants.DN_OPT_IN.value),
                           c.DictConstants.DIGEST_OPT_IN.value: address.get(c.DictConstants.DIGEST_OPT_IN.value),
                           c.DictConstants.PHYSICAL_ADDRESS_ID.value: address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value),
                           c.DictConstants.ZIP11.value: address.get(c.DictConstants.ZIP11.value),
                           c.DictConstants.SMS_EDU_ENABLED.value: address.get(c.DictConstants.SMS_EDU_ENABLED.value),
                           c.DictConstants.SMS_DEU_ENABLED.value: address.get(c.DictConstants.SMS_DEU_ENABLED.value),
                           c.DictConstants.SMS_DDU_ENABLED.value: address.get(c.DictConstants.SMS_DDU_ENABLED.value),
                           c.DictConstants.SMS_AFP_ENABLED.value: address.get(c.DictConstants.SMS_AFP_ENABLED.value),
                           c.DictConstants.SMS_PD_ENABLED.value: address.get(c.DictConstants.SMS_PD_ENABLED.value),
                           c.DictConstants.SMS_PIT_ENABLED.value: address.get(c.DictConstants.SMS_PIT_ENABLED.value),
                           c.DictConstants.EMAIL_EDU_ENABLED.value: address.get(c.DictConstants.EMAIL_EDU_ENABLED.value),
                           c.DictConstants.EMAIL_DEU_ENABLED.value: address.get(c.DictConstants.EMAIL_DEU_ENABLED.value),
                           c.DictConstants.EMAIL_DDU_ENABLED.value: address.get(c.DictConstants.EMAIL_DDU_ENABLED.value),
                           c.DictConstants.EMAIL_AFP_ENABLED.value: address.get(c.DictConstants.EMAIL_AFP_ENABLED.value),
                           c.DictConstants.EMAIL_PD_ENABLED.value: address.get(c.DictConstants.EMAIL_PD_ENABLED.value),
                           c.DictConstants.EMAIL_PIT_ENABLED.value: address.get(c.DictConstants.EMAIL_PIT_ENABLED.value),
                           c.DictConstants.PACKAGE_EMAIL.value: address.get(c.DictConstants.PACKAGE_EMAIL.value),
                           c.DictConstants.PACKAGE_NUMBER.value: address.get(c.DictConstants.PACKAGE_NUMBER.value)}

        return str(json.dumps(document_values)).encode("utf-8")

    else:
        document_values = {c.DictConstants.ACCOUNT_ID.value: account.get(c.DictConstants.ACCOUNT_ID.value),
                       c.DictConstants.EMAIL_ADDRESS.value: account.get(c.DictConstants.EMAIL_ADDRESS.value),
                       c.DictConstants.UNSUBSCRIBE_TOKEN.value: account.get(c.DictConstants.UNSUBSCRIBE_TOKEN.value),
                       c.DictConstants.FIRST_NAME.value: account.get(c.DictConstants.FIRST_NAME.value),
                       c.DictConstants.PRIMARY_ADDRESS_IND.value: address.get(c.DictConstants.PRIMARY_ADDRESS_IND.value),
                       c.DictConstants.DN_OPT_IN.value: address.get(c.DictConstants.DN_OPT_IN.value),
                       c.DictConstants.DIGEST_OPT_IN.value: address.get(c.DictConstants.DIGEST_OPT_IN.value),
                       c.DictConstants.PHYSICAL_ADDRESS_ID.value: address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value),
                       c.DictConstants.ZIP11.value: address.get(c.DictConstants.ZIP11.value)}

        return str(json.dumps(document_values)).encode("utf-8")




def create_email_cache_value(primary_address, secondary_address):
    zip11_list = []

    if primary_address is not None and '1' == primary_address.get(c.DictConstants.IS_ACTIVE.value):
        zip11_list.append(primary_address.get(c.DictConstants.ZIP11.value))

    if secondary_address is not None and '1' == secondary_address.get(c.DictConstants.IS_ACTIVE.value):
        zip11_list.append(secondary_address.get(c.DictConstants.ZIP11.value))

    return ','.join(zip11_list)