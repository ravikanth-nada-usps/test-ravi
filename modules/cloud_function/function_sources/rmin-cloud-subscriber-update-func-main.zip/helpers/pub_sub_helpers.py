import json
import google.cloud.logging
import logging
from retry import retry
from utilities import account_revision_pb2
from utilities import physical_address_revision_pb2
from helpers import date_helpers
import os

from constants import constants as c

logger = google.cloud.logging.Client()
logger.setup_logging()


def generate_account_revision_message(account, account_old, principal_id):
    my_usps_toggle = os.environ.get('PROCESS_MY_USPS_FIELDS', False)

    account_revision = account_revision_pb2.AccountRevision

    account_revision.account_type_old = account_old.get(c.DictConstants.ACCOUNT_TYPE.value) if account_old is not None else ''
    account_revision.account_type_new = account.get(c.DictConstants.ACCOUNT_TYPE.value)
    account_revision.banner_opt_out_old = account_old.get(c.DictConstants.BANNER_OPT_OUT.value) if account_old is not None else '0'
    account_revision.banner_opt_out_new = account.get(c.DictConstants.BANNER_OPT_OUT.value)
    account_revision.banner_start_date = account.get(c.DictConstants.BANNER_START_DATE.value)
    account_revision.is_active_old = account_old.get(c.DictConstants.IS_ACTIVE.value) if account_old is not None else '0'
    account_revision.is_active_new = account.get(c.DictConstants.IS_ACTIVE.value)
    account_revision.email_address_old = account_old.get(c.DictConstants.EMAIL_ADDRESS.value) if account_old is not None else ''
    account_revision.email_address_new = account.get(c.DictConstants.EMAIL_ADDRESS.value)
    account_revision.first_name_old = account_old.get(c.DictConstants.FIRST_NAME.value) if account_old is not None else ''
    account_revision.first_name_new = account.get(c.DictConstants.FIRST_NAME.value)
    account_revision.principal_id = principal_id
    account_revision.account_id = account.get(c.DictConstants.ACCOUNT_ID.value)
    account_revision.unsubscribe_token = account.get(c.DictConstants.UNSUBSCRIBE_TOKEN.value)
    account_revision.time_stamp = date_helpers.generate_bq_timestamp()

    if my_usps_toggle:
        account_revision.esof_preferred_location_old = account_old.get(c.DictConstants.ESOF_PREFERRED_LOCATION.value) if account_old is not None else ''
        account_revision.esof_preferred_location_new = account.get(c.DictConstants.ESOF_PREFERRED_LOCATION.value)

    data = str(json.dumps(protobuf_to_dict(account_revision))).encode("utf-8")

    return data


def generate_physical_address_revision_message(address, address_old, principal_id):
    if address is not None:
        physical_address_revision = physical_address_revision_pb2.PhysicalAddressRevision

        physical_address_revision.principal_id = principal_id
        physical_address_revision.time_stamp = date_helpers.generate_bq_timestamp()
        physical_address_revision.zip11_old = address_old.get(c.DictConstants.ZIP11.value) if address_old is not None else ''
        physical_address_revision.zip11_new = address.get(c.DictConstants.ZIP11.value)
        physical_address_revision.coa_pending_old = address_old.get(c.DictConstants.COA_PENDING.value) if address_old is not None else '0'
        physical_address_revision.coa_pending_new = address.get(c.DictConstants.COA_PENDING.value)
        physical_address_revision.dn_opt_in_old = address_old.get(c.DictConstants.DN_OPT_IN.value) if address_old is not None else '0'
        physical_address_revision.dn_opt_in_new = address.get(c.DictConstants.DN_OPT_IN.value)
        physical_address_revision.digest_opt_in_old = address_old.get(c.DictConstants.DIGEST_OPT_IN.value) if address_old is not None else '0'
        physical_address_revision.digest_opt_in_new = address.get(c.DictConstants.DIGEST_OPT_IN.value)
        physical_address_revision.is_active_old = address_old.get(c.DictConstants.IS_ACTIVE.value) if address_old is not None else '0'
        physical_address_revision.is_active_new = address.get(c.DictConstants.IS_ACTIVE.value)
        physical_address_revision.package_email_old = address_old.get(c.DictConstants.PACKAGE_EMAIL.value) if address_old is not None else ''
        physical_address_revision.package_email_new = address.get(c.DictConstants.PACKAGE_EMAIL.value)
        physical_address_revision.package_number_old = address_old.get(c.DictConstants.PACKAGE_NUMBER.value) if address_old is not None else ''
        physical_address_revision.package_number_new = address.get(c.DictConstants.PACKAGE_NUMBER.value)
        physical_address_revision.email_afp_enabled_old = address_old.get(c.DictConstants.EMAIL_AFP_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.email_afp_enabled_new = address.get(c.DictConstants.EMAIL_AFP_ENABLED.value)
        physical_address_revision.email_ddu_enabled_old = address_old.get(c.DictConstants.EMAIL_DDU_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.email_ddu_enabled_new = address.get(c.DictConstants.EMAIL_DDU_ENABLED.value)
        physical_address_revision.email_deu_enabled_old = address_old.get(c.DictConstants.EMAIL_DEU_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.email_deu_enabled_new = address.get(c.DictConstants.EMAIL_DEU_ENABLED.value)
        physical_address_revision.email_edu_enabled_old = address_old.get(c.DictConstants.EMAIL_EDU_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.email_edu_enabled_new = address.get(c.DictConstants.EMAIL_EDU_ENABLED.value)
        physical_address_revision.email_pd_enabled_old = address_old.get(c.DictConstants.EMAIL_PD_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.email_pd_enabled_new = address.get(c.DictConstants.EMAIL_PD_ENABLED.value)
        physical_address_revision.email_pit_enabled_old = address_old.get(c.DictConstants.EMAIL_PIT_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.email_pit_enabled_new = address.get(c.DictConstants.EMAIL_PIT_ENABLED.value)
        physical_address_revision.sms_afp_enabled_old = address_old.get(c.DictConstants.SMS_AFP_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.sms_afp_enabled_new = address.get(c.DictConstants.SMS_AFP_ENABLED.value)
        physical_address_revision.sms_ddu_enabled_old = address_old.get(c.DictConstants.SMS_DDU_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.sms_ddu_enabled_new = address.get(c.DictConstants.SMS_DDU_ENABLED.value)
        physical_address_revision.sms_deu_enabled_old = address_old.get(c.DictConstants.SMS_DEU_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.sms_deu_enabled_new = address.get(c.DictConstants.SMS_DEU_ENABLED.value)
        physical_address_revision.sms_edu_enabled_old = address_old.get(c.DictConstants.SMS_EDU_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.sms_edu_enabled_new = address.get(c.DictConstants.SMS_EDU_ENABLED.value)
        physical_address_revision.sms_pd_enabled_old = address_old.get(c.DictConstants.SMS_PD_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.sms_pd_enabled_new = address.get(c.DictConstants.SMS_PD_ENABLED.value)
        physical_address_revision.sms_pit_enabled_old = address_old.get(c.DictConstants.SMS_PIT_ENABLED.value) if address_old is not None else '0'
        physical_address_revision.sms_pit_enabled_new = address.get(c.DictConstants.SMS_PIT_ENABLED.value)
        physical_address_revision.physical_address_id = address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value)
        physical_address_revision.primary_address_ind = address.get(c.DictConstants.PRIMARY_ADDRESS_IND.value)

        data = str(json.dumps(protobuf_to_dict(physical_address_revision))).encode("utf-8")

        return data
    else:
        return None

def generate_package_notification_settings_message(address, principal_id):
    if address is not None and '1' == address.get(c.DictConstants.IS_ACTIVE.value):
        package_notification_settings = {c.DictConstants.PRINCIPAL_ID.value: principal_id,
                                     c.DictConstants.ZIP11.value: address.get(c.DictConstants.ZIP11.value),
                                     c.DictConstants.PACKAGE_EMAIL.value: address.get(c.DictConstants.PACKAGE_EMAIL.value),
                                     c.DictConstants.PACKAGE_NUMBER.value: address.get(c.DictConstants.PACKAGE_NUMBER.value),
                                     c.DictConstants.EMAIL_AFP_ENABLED.value: address.get(c.DictConstants.EMAIL_AFP_ENABLED.value),
                                     c.DictConstants.EMAIL_DDU_ENABLED.value: address.get(c.DictConstants.EMAIL_DDU_ENABLED.value),
                                     c.DictConstants.EMAIL_DEU_ENABLED.value: address.get(c.DictConstants.EMAIL_DEU_ENABLED.value),
                                     c.DictConstants.EMAIL_EDU_ENABLED.value: address.get(c.DictConstants.EMAIL_EDU_ENABLED.value),
                                     c.DictConstants.EMAIL_PD_ENABLED.value: address.get(c.DictConstants.EMAIL_PD_ENABLED.value),
                                     c.DictConstants.EMAIL_PIT_ENABLED.value: address.get(c.DictConstants.EMAIL_PIT_ENABLED.value),
                                     c.DictConstants.SMS_AFP_ENABLED.value: address.get(c.DictConstants.SMS_AFP_ENABLED.value),
                                     c.DictConstants.SMS_DDU_ENABLED.value: address.get(c.DictConstants.SMS_DDU_ENABLED.value),
                                     c.DictConstants.SMS_DEU_ENABLED.value: address.get(c.DictConstants.SMS_DEU_ENABLED.value),
                                     c.DictConstants.SMS_EDU_ENABLED.value: address.get(c.DictConstants.SMS_EDU_ENABLED.value),
                                     c.DictConstants.SMS_PD_ENABLED.value: address.get(c.DictConstants.SMS_PD_ENABLED.value),
                                     c.DictConstants.SMS_PIT_ENABLED.value: address.get(c.DictConstants.SMS_PIT_ENABLED.value)}

        data = str(json.dumps(package_notification_settings)).encode("utf-8")

        return data

    else:
        return None

def generate_subscriber_opt_in_settings_message(address):
    subscriber_opt_in_settings = {c.DictConstants.PHYSICAL_ADDRESS_ID.value: address.get(c.DictConstants.PHYSICAL_ADDRESS_ID.value),
                                  c.DictConstants.ZIP11_NEW.value: address.get(c.DictConstants.ZIP11.value),
                                  c.DictConstants.DN_OPT_IN_NEW.value: address.get(c.DictConstants.DN_OPT_IN.value),
                                  c.DictConstants.DIGEST_OPT_IN_NEW.value: address.get(c.DictConstants.DIGEST_OPT_IN.value),
                                  c.DictConstants.TIMESTAMP.value: date_helpers.generate_bq_timestamp()}

    data = str(json.dumps(subscriber_opt_in_settings)).encode("utf-8")

    return data

@retry(tries=6, delay=5, backoff=2, max_delay=120)
def write_to_pubsub(message, publisher_client, topic_path):
    future = publisher_client.publish(topic_path, message)
    return future.result()

def protobuf_to_dict(proto_obj):
    key_list = proto_obj.DESCRIPTOR.fields_by_name.keys()
    d = {}
    for key in key_list:
        d[key] = getattr(proto_obj, key)
    return d
