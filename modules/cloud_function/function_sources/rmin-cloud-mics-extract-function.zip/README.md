# Launching rmin-cloud-mics-extract-function in cloud
This code shows how to use Cloud Run and Cloud Scheduler to query BigQuery and return results (with custom headers) to specified emails (in properties file).

## Steps:

**1) Once you commit your code**

* After the job has successfully built, you need to deploy the DEV

**2) Run your gcloud command in the gcloud terminal**

* edit to fit your job, MUST set the following:



<details>
Update Parameters 
--vpc-connector
--service-account
--set-env-vars
	bigQueryTable
	projectId
	topicId

</details>


```bash
# DEV3 example

gcloud functions deploy rmin-cloud-mics-extract-function-000d \
--gen2 \
--region=us-central1 \
--runtime=java17 \
--trigger-http \
--project=uspscio-idc-9060-00-sandbox \
--entry-point=com.function.MicsExtractFunction \
--ingress-settings=INTERNAL_ONLY \
--memory=350 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-00-sandbox/locations/us-central1/connectors/rmin-dev-peripheral-conn \
--timeout=540s \
--service-account=dev-mics-subscriber-extract@uspscio-idc-9060-00-sandbox.iam.gserviceaccount.com \
--set-env-vars=bigQueryTable=uspscio-idc-9060-00-sandbox.bigquery_uspscio_9060_operational_logs,projectId=uspscio-idc-9060-00-sandbox,topicId=rmin-mics-extract-topic-c-01d,maxRetryCount=5,queueId=micsSubscriberExtract-queue,locationId=us-central1,serviceAccount=dev-mics-subscriber-extract@uspscio-idc-9060-00-sandbox.iam.gserviceaccount.com,url=https://rmin-cloud-mics-subscriber-extract-mpv2r6lwfa-uc.a.run.app

```
```bash
# SIT3 example
```

**4) Copy the URL from the cloud run job you just created and create your cloud scheduler (This is found by clicking inside your job inside Cloud Function)**
* Run the gcloud scheduler command in the gcloud terminal
    * uri _(URL from your cloud run job)_
    * oidc-service-account-email _(service account you set for the deploy command)_
- Schedule 0 14 * * * is currently set for every day at 2pm Local time
- Note below is Eastern Local Time

```bash
Eastern
gcloud scheduler jobs create http rmin-cloud-mics-extract-Eastern \
--schedule="0 14 * * *" \
--uri="https://us-central1-uspscio-idc-9060-00-sandbox.cloudfunctions.net/rmin-cloud-mics-extract-function-000d" \
--http-method=POST \
--message-body="US/Eastern" \
--time-zone="America/New_York" \
--headers="Content-Type=text/plain" \
--location=us-central1 \
--oidc-service-account-email="dev-mics-subscriber-extract@uspscio-idc-9060-00-sandbox.iam.gserviceaccount.com" \
--description="Mics Extract - Eastern time zone"

