package com.function;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.IdTokenCredentials;
import com.google.auth.oauth2.IdTokenProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.util.Arrays;

public class AuthenticationTokenManager {
    private static AuthenticationTokenManager instance;
    private final String baseApiUrl;
    private IdTokenCredentials tokenCredentials;
    private static final Logger LOG = LoggerFactory.getLogger(AuthenticationTokenManager.class);


    public AuthenticationTokenManager(String baseApiUrl) {
        this.baseApiUrl = baseApiUrl;
    }

    public static synchronized AuthenticationTokenManager create(String url) throws IOException {
        if (instance == null) {
            instance = new AuthenticationTokenManager(url);
            instance.getNewTokenCredentials();
        }

        return instance;
    }

    public IdTokenCredentials getTokenCredentials() throws IOException {
        tokenCredentials.refreshIfExpired();
        return tokenCredentials;
    }

    private void getNewTokenCredentials() throws IOException {
        GoogleCredentials credentials = GoogleCredentials.getApplicationDefault();
        if (!(credentials instanceof IdTokenProvider)) {
            throw new IllegalArgumentException(
                    "Credentials are not an instance of IdTokenProvider.");
        }
        LOG.debug("apiUrl retrieved is :{}",baseApiUrl);
        tokenCredentials =
                IdTokenCredentials.newBuilder()
                        .setIdTokenProvider((IdTokenProvider) credentials)
                        .setTargetAudience(baseApiUrl)
                        .setOptions(
                                Arrays.asList(
                                        IdTokenProvider.Option.FORMAT_FULL,
                                        IdTokenProvider.Option.LICENSES_TRUE))
                        .build();
    }
}
