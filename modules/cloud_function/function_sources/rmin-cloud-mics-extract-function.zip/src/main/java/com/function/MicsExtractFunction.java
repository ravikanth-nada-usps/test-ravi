package com.function;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.api.client.http.ByteArrayContent;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonObjectParser;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.logging.Logger;
import com.google.cloud.tasks.v2.CloudTasksClient;
import com.google.cloud.tasks.v2.HttpMethod;
import com.google.cloud.tasks.v2.OidcToken;

import com.google.cloud.tasks.v2.QueueName;
import com.google.cloud.tasks.v2.Task;
import com.google.protobuf.ByteString;
import com.google.protobuf.Duration;
import java.nio.charset.Charset;


public class MicsExtractFunction implements HttpFunction {
    private static final Logger LOGGER = Logger.getLogger(MicsExtractFunction.class.getName());
    private AuthenticationTokenManager tokenManager;
    private static final HttpTransport HTTP_TRANSPORT = new NetHttpTransport();
    private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
    private static final ObjectMapper MAPPER = new ObjectMapper().findAndRegisterModules();

    @Override
    public void service(HttpRequest request, HttpResponse response) throws IOException {

        try {
            var projectId = System.getenv("projectId");
            var bigQueryTable = System.getenv("bigQueryTable");
            var timeZoneArgs = request.getReader().readLine().toString();
            var maxRetries = System.getenv("maxRetryCount");
            BigQuery bigquery = BigQueryOptions.newBuilder().setProjectId(projectId).build().getService();

            String micsQuery = "SELECT MICS_ID, MICS_CODE, TIMEZONE, MICS_HOST, MICS_PORT, USERNAME \r\n"
                    + " FROM `" + bigQueryTable + ".MICS` \r\n "
                    + " where MICS_ID is NOT NULL and  TIMEZONE = '" + timeZoneArgs + "' and MICS_HOST is not null and USERNAME is not null \r\n"
                    + " and IS_ACTIVE = 1 order by MICS_ID desc;";

            QueryJobConfiguration micsQueryConfig = QueryJobConfiguration.newBuilder(micsQuery).build();

            Job micsQueryJob = bigquery.create(JobInfo.newBuilder(micsQueryConfig).build());
            micsQueryJob = micsQueryJob.waitFor();

            if (micsQueryJob == null) {
                throw new Exception("Job No Longer Exists");
            }

            if (micsQueryJob.getStatus().getError() != null) {
                throw new Exception(micsQueryJob.getStatus().getError().toString());
            }

            TableResult micsResults = micsQueryJob.getQueryResults();

            LOGGER.info("Timezone: " + timeZoneArgs + ", Mics Count: " + micsResults.getTotalRows());
            try {
                LOGGER.info("Start pulling the Zip5s per mics_id");
                for(FieldValueList micsRow: micsResults.iterateAll()) {
                    BigDecimal micsId = micsRow.get("MICS_ID").getNumericValue();
                    String micsZipQuery = "SELECT ZIP5 FROM `" + bigQueryTable + ".MICS_ZIP` where MICS_ID = " + micsId + ";";

                    QueryJobConfiguration micsZipQueryConfig = QueryJobConfiguration.newBuilder(micsZipQuery).build();


                    Job micsZipQueryJob = bigquery.create(JobInfo.newBuilder(micsZipQueryConfig).build());

                    micsZipQueryJob = micsZipQueryJob.waitFor();


                    if (micsZipQueryJob == null) {

                        throw new Exception("Job No Longer Exists");

                    } if (micsZipQueryJob.getStatus().getError() != null) {

                        throw new Exception(micsZipQueryJob.getStatus().getError().toString());

                    }
                    TableResult micsZipResults = micsZipQueryJob.getQueryResults();
                    try {
                        tokenManager = AuthenticationTokenManager.create(System.getenv("url"));
                        // com.google.api.client.http.HttpResponse httpResponse = null;
                        ArrayList<String> zip5List = new ArrayList<String>();
                        JSONObject micsExtractMsg = new JSONObject();
                        if(micsZipResults.getTotalRows() > 0) {
                            //Mics Table info
                            micsExtractMsg.put("micsId", micsRow.get("MICS_ID").getNumericValue().intValue());
                            micsExtractMsg.put("micsCode", micsRow.get("MICS_CODE").getValue());
                            micsExtractMsg.put("micsHost", micsRow.get("MICS_HOST").getValue());
                            micsExtractMsg.put("micsPort", micsRow.get("MICS_PORT").getValue());
                            micsExtractMsg.put("userName", micsRow.get("USERNAME").getValue());

                            for(FieldValueList micsZip5: micsZipResults.iterateAll()) {
                                zip5List.add( micsZip5.get("ZIP5").getValue().toString());
                            }
                            micsExtractMsg.put("zip5List", zip5List);
                            micsExtractMsg.put("timeZone", timeZoneArgs);

                        } else {
                            //Mics Table info
                            micsExtractMsg.put("micsId", micsRow.get("MICS_ID").getNumericValue().intValue());
                            micsExtractMsg.put("micsCode", micsRow.get("MICS_CODE").getValue());
                            micsExtractMsg.put("micsHost", micsRow.get("MICS_HOST").getValue());
                            micsExtractMsg.put("micsPort", micsRow.get("MICS_PORT").getValue());
                            micsExtractMsg.put("userName", micsRow.get("USERNAME").getValue());
                            micsExtractMsg.put("zip5List", zip5List);
                            micsExtractMsg.put("timeZone", timeZoneArgs);
                        }
                        //  httpResponse = micsSubscriberExtractRequest(micsExtractMsg, Integer.parseInt(maxRetries));

                        createTask(projectId,micsExtractMsg);


                    } catch(Exception e) {
                        LOGGER.info("Error Sending to Mics Subscriber Extract Cloud Run: " + e);
                    }

                }

            } catch(Exception e) {
                LOGGER.info("Error Loading MicsIds and Zip5s: " + e);
            }

            LOGGER.info("Zip5's Have Successfully added to MICS Extract Msgs");

        } catch(Exception e) {
            LOGGER.info("Error: " + e);
        }
    }

    private ByteArrayContent createByteArrayContent(JSONObject content) throws JsonProcessingException {
        return ByteArrayContent.fromString("application/json", content.toString());
    }


    public com.google.api.client.http.HttpResponse micsSubscriberExtractRequest(JSONObject micsSubscriberMsg , int maxRetries)  throws IOException, InterruptedException {
        var url = System.getenv("url");
        boolean success = false;
        int retryCount = 0;
        com.google.api.client.http.HttpResponse response = null;

        while (!success && retryCount < maxRetries) {
            try{
                LOGGER.info("Attempting to POST: " + micsSubscriberMsg.toString());
                var credentials = tokenManager.getTokenCredentials();
                var request = HTTP_TRANSPORT
                        .createRequestFactory(
                                r -> {
                                    r.setParser(new JsonObjectParser(JSON_FACTORY));
                                    new HttpCredentialsAdapter(credentials).initialize(r);
                                })
                        .buildPostRequest(new GenericUrl(url), createByteArrayContent(micsSubscriberMsg));

                response = request.execute();
                success = true;
            } catch (Exception e) {
                LOGGER.info("Error occurred calling Mics Subscriber Extract API url "  + url + " error: "  + e);
                retryCount++;
                if(retryCount < maxRetries){
                    LOGGER.info(
                            "Failed to successfully call Mics Subscriber Extract API url after 5 retries");
                    //Break out of loop if max retries hit
                    success = true;
                }
            }
        }
        return response;


    }


    // Create a task with a HTTP target using the Cloud Tasks client.
    public static void createTask(String projectId,JSONObject micsExtractMsg)
            throws IOException {
        var locationId = System.getenv("locationId");
        var queueId = System.getenv("queueId");
        var serviceAccount = System.getenv("serviceAccount");
        var url = System.getenv("url");
        // Instantiates a client.
        try (CloudTasksClient client = CloudTasksClient.create()) {

            String payload = micsExtractMsg.toString();
            OidcToken.Builder oidcTokenBuilder =
                    OidcToken.newBuilder().setServiceAccountEmail(serviceAccount);
            LOGGER.info("oidcToken: " + oidcTokenBuilder + "serviceAccount : " + serviceAccount);
            // Construct the fully qualified queue name.
            String queuePath = QueueName.of(projectId, locationId, queueId).toString();
            LOGGER.info("Attempting to POST a task: " + payload);

            // Define the dispatch deadline duration
            Duration dispatchDeadline = Duration.newBuilder()
                    .setSeconds(1800)  // 1800 seconds = 30 minutes
                    .build();

            // Construct the task body.
            Task taskBuilder  =
                    Task.newBuilder()
                            .setHttpRequest(com.google.cloud.tasks.v2.HttpRequest.newBuilder()
                                    .setBody(ByteString.copyFrom(payload, Charset.defaultCharset()))
                                    .setUrl(url)
                                    .setHttpMethod(HttpMethod.POST)
                                    .setOidcToken(oidcTokenBuilder)
                                    .build())
                                    .setDispatchDeadline(dispatchDeadline).build();

            // Send create task request.
            Task task = client.createTask(queuePath, taskBuilder);
            LOGGER.info("Task created: " + task.getName());
        }catch (Exception e) {
            LOGGER.info("Error occurred while creating task" +e);
        }
    }

}