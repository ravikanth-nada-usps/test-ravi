from cloudevents.http import CloudEvent
from google.events.cloud import firestore as firestoredata
from google.cloud import storage
from google.cloud import firestore
from PIL import Image
from io import BytesIO
from retry import retry

import re
import google.cloud.logging
import functions_framework
import os
import logging

db = firestore.Client(database=os.environ.get("DATABASE","(default)"))
logger = google.cloud.logging.Client()
logger.setup_logging()

@functions_framework.cloud_event
def receive_firestore_event(cloud_event: CloudEvent) -> None:
    """Triggers by a change to a Firestore document.
    Args:
        cloud_event: cloud event with information on the firestore event trigger
    """
    firestore_payload = firestoredata.DocumentEventData()
    firestore_payload._pb.ParseFromString(cloud_event.data)

    document_values = firestore_payload.value
    piece_type = document_values.fields["pieceType"].string_value
    zip11 = document_values.fields["zip11"].string_value
    unique_code = document_values.fields["uniqueCode"].string_value
    
    if piece_type == "MicsLetter":
        gcs_path = document_values.fields['image'].map_value.fields['imagePath'].string_value
        regex = re.compile('gs:\/\/(.*?)\/(.*)')
        match = re.search(regex, gcs_path)
        bucket_name = match.group(1)
        image_name = match.group(2)

        wid = hgt = 0
        try:
            wid,hgt = get_image_dimensions(bucket_name, image_name)
        except Exception as e:
            logging.exception(f"Failed to grab image dimensions for {gcs_path} ")

        if wid != 0 and hgt != 0:
            try:
                update_mailpiece_dimensions(zip11,unique_code,wid,hgt)
            except Exception as e:
                logging.exception(f"Failed to update image dimensions for {gcs_path}")

@retry(tries=5, delay=1, backoff=2, max_delay=10)
def update_mailpiece_dimensions(zip11,unique_code,wid,hgt):
    transaction = db.transaction()
    mailpiece_doc = db.collection("dashboards").document(zip11).collection("mailpieces").document(unique_code)
    
    result = mailpiece_transaction(transaction, mailpiece_doc,wid,hgt)
    
    logging.info(result)
    
@firestore.transactional
def mailpiece_transaction(transaction,mailpiece_doc,wid,hgt):
    snapshot = mailpiece_doc.get(transaction=transaction)
    existing_width = snapshot.get("image.imageWidth")
    existing_height = snapshot.get("image.imageHeight")
    gcs_path = snapshot.get("image.imagePath")
    
    if(existing_width == 0 and existing_height == 0):
        transaction.update(mailpiece_doc, {"image.imageHeight":hgt,"image.imageWidth":wid})
        return f"Updated dimensions for {gcs_path} to {wid}x{hgt}"
    else:
        return f"Skipping over dimension update for {gcs_path}, existing dimensions were {existing_width}x{existing_height}"
    
@retry(tries=5, delay=1, backoff=2, max_delay=10)
def get_image_dimensions(bucket_name, image_name):
    wid = hgt = 0
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.get_blob(image_name)
    data = BytesIO(blob.download_as_string())
    img = Image.open(data)
    wid,hgt = img.size

    return wid,hgt
