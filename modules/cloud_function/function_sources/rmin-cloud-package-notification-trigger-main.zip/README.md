# rmin-cloud-package-notification-trigger

## Local Build

```shell
mvn install -D"https.protocols"=TLSv1.2
```

## Deploy 

### DEV2

```shell
gcloud functions deploy rmin-cloud-package-notification-trigger-002d \
--gen2 \
--region=us-central1 \
--runtime=java11 \
--trigger-location=nam5 \
--entry-point=com.function.CloudFunction \
--trigger-event-filters=type=google.cloud.firestore.document.v1.created \
--trigger-event-filters=database='dashboard' \
--trigger-event-filters-path-pattern=document='dashboards/{zip11}/inboundPackages/{inboundPackages}' \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-02d/locations/us-central1/connectors/rmin-dev-peripheral-conn \
--timeout=540s \
--service-account=dev-pkg-notif-trigger@uspscio-idc-9060-02d.iam.gserviceaccount.com \
--set-env-vars=projectId=uspscio-idc-9060-02d,topicId=rmin-package-notification-topic-c-002d,redisHost=10.100.1.44,redisPort=6379


### PERF

```shell
gcloud functions deploy rmin-cloud-package-notification-trigger-001d \
--gen2 \
--region=us-central1 \
--runtime=java11 \
--trigger-location=nam5 \
--entry-point=com.function.CloudFunction \
--trigger-event-filters=type=google.cloud.firestore.document.v1.created \
--trigger-event-filters=database='dashboard' \
--trigger-event-filters-path-pattern=document='dashboards/{zip11}/inboundPackages/{inboundPackages}' \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-01d/locations/us-central1/connectors/rmin-dev-peripheral-conn \
--timeout=540s \
--service-account=dev-pkg-notif-trigger@uspscio-idc-9060-01d.iam.gserviceaccount.com \
--set-env-vars=projectId=uspscio-idc-9060-01d,topicId=rmin-package-notification-topic-c-001d,redisHost=,redisPort=6379

```


### SIT2

```shell
gcloud functions deploy rmin-cloud-package-notification-trigger-002s \
--gen2 \
--region=us-central1 \
--runtime=java11 \
--trigger-location=nam5 \
--entry-point=com.function.CloudFunction \
--trigger-event-filters=type=google.cloud.firestore.document.v1.created \
--trigger-event-filters=database='dashboard' \
--trigger-event-filters-path-pattern=document='dashboards/{zip11}/inboundPackages/{inboundPackages}' \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-02s/locations/us-central1/connectors/rmin-sit-peripheral-conn \
--timeout=540s \
--service-account=sit-pkg-notif-trigger@uspscio-idc-9060-02s.iam.gserviceaccount.com \
--set-env-vars=projectId=uspscio-idc-9060-02s,topicId=rmin-package-notification-topic-c-002s,redisHost=,redisPort=6379

### CAT

```shell
gcloud functions deploy rmin-cloud-package-notification-trigger-001c \
--gen2 \
--region=us-central1 \
--runtime=java11 \
--trigger-location=nam5 \
--entry-point=com.function.CloudFunction \
--trigger-event-filters=type=google.cloud.firestore.document.v1.created \
--trigger-event-filters=database='dashboard' \
--trigger-event-filters-path-pattern=document='dashboards/{zip11}/inboundPackages/{inboundPackages}' \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-01c/locations/us-central1/connectors/rmin-cat-peripheral-conn \
--timeout=540s \
--service-account=cat-pkg-notif-trigger@uspscio-idc-9060-01c.iam.gserviceaccount.com \
--set-env-vars=projectId=uspscio-idc-9060-01c,topicId=rmin-package-notification-topic-c-001c,redisHost=,redisPort=6379

### PROD

```shell
gcloud functions deploy rmin-cloud-package-notification-trigger-001p \
--gen2 \
--region=us-central1 \
--runtime=java11 \
--trigger-location=nam5 \
--entry-point=com.function.CloudFunction \
--trigger-event-filters=type=google.cloud.firestore.document.v1.created \
--trigger-event-filters=database='dashboard' \
--trigger-event-filters-path-pattern=document='dashboards/{zip11}/inboundPackages/{inboundPackages}' \
--ingress-settings=INTERNAL_ONLY \
--memory=256 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-01c/locations/us-central1/connectors/rmin-prod-peripheral-conn \
--timeout=540s \
--service-account=prod-pkg-notif-trigger@uspscio-idc-9060-01p.iam.gserviceaccount.com \
--set-env-vars=projectId=uspscio-idc-9060-01p,topicId=rmin-package-notification-topic-c-001p,redisHost=,redisPort=6379
