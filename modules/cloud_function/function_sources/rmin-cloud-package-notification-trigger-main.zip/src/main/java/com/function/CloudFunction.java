package com.function;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.google.cloud.functions.CloudEventsFunction;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.events.cloud.firestore.v1.DocumentEventData;
import com.google.events.cloud.firestore.v1.Value;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.ByteString;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;

import io.cloudevents.CloudEvent;

public class CloudFunction implements CloudEventsFunction {
    private static final Logger logger = Logger.getLogger(CloudFunction.class.getName());
    private JedisPool jedisPool;
    private Publisher emailPublisher;

    @Override
    public void accept(CloudEvent event) throws InvalidProtocolBufferException {

        try {
            jedisPool = SubscriberCacheConnection.getPool(System.getenv("redisHost"));
            emailPublisher = PackageNotificationPubsub.getPubSub();
            var mpToggle = Boolean.parseBoolean(System.getenv("mpToggle"));
            var publishSmsMessage = Boolean.parseBoolean(System.getenv("publishSmsMessage"));

            DocumentEventData firestorEventData = DocumentEventData.parseFrom(event.getData().toBytes());

            if(!firestorEventData.getValue().toString().isBlank()) {

                Map<String, Value> fields = firestorEventData.getValue().getFieldsMap();
                String zip11 = fields.get("zip11").getStringValue();

                //Pull the list for zip11
                Set<String> principalIdZip11 = retrievePrincipalIdZip11(jedisPool, zip11);
                if(!principalIdZip11.isEmpty()){
                    String zip5 =  StringUtils.left(zip11, 5);

                    for(String processUserIdZip11 : principalIdZip11) {
                        String user = retrieveUserInfo(jedisPool, zip5, processUserIdZip11);

                        if(user != null) {

                            try {
                                JSONObject userInfo = new JSONObject(user);
                                JSONObject packageNotificationMsg = new JSONObject();

                                packageNotificationMsg.put("zip11", zip11);
                                packageNotificationMsg.put("principalId", processUserIdZip11.split("-")[0]);
                                packageNotificationMsg.put("impb", fields.get("impb").getStringValue());
                                packageNotificationMsg.put("emailAFPEnabled", userInfo.getString("email_afp_enabled"));
                                packageNotificationMsg.put("emailDDUEnabled", userInfo.getString("email_ddu_enabled"));
                                packageNotificationMsg.put("emailDEUEnabled", userInfo.getString("email_deu_enabled"));
                                packageNotificationMsg.put("emailEDUEnabled", userInfo.getString("email_edu_enabled"));
                                packageNotificationMsg.put("emailPDEnabled", userInfo.getString("email_pd_enabled"));
                                packageNotificationMsg.put("emailPITEnabled", userInfo.getString("email_pit_enabled"));
                                packageNotificationMsg.put("smsAFPEnabled", userInfo.getString("sms_afp_enabled"));
                                packageNotificationMsg.put("smsDDUEnabled", userInfo.getString("sms_ddu_enabled"));
                                packageNotificationMsg.put("smsDEUEnabled", userInfo.getString("sms_deu_enabled"));
                                packageNotificationMsg.put("smsEDUEnabled", userInfo.getString("sms_edu_enabled"));
                                packageNotificationMsg.put("smsPDEnabled", userInfo.getString("sms_pd_enabled"));
                                packageNotificationMsg.put("smsPITEnabled", userInfo.getString("sms_pit_enabled"));
                                packageNotificationMsg.put("packageEmail", userInfo.getString("package_email"));
                                packageNotificationMsg.put("packagePhone", userInfo.getString("package_number"));

                                //Toggle for to load MpDate and MpSuffix
                                if(mpToggle) {
                                    packageNotificationMsg.put("mpDate", fields.get("mpDate").getStringValue());
                                    packageNotificationMsg.put("mpSuffix", fields.get("mpSuffix").getStringValue());
                                }

                                logger.info("Message Published " + fields.get("impb").getStringValue());

                                PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
                                        .setData(ByteString.copyFromUtf8(packageNotificationMsg.toString()))
                                        .build();
                                emailPublisher.publish(pubsubMessage);

                                if(publishSmsMessage){
                                    Publisher smsPublisher = PackageSmsNotificationPubsub.getPubSub();
                                    smsPublisher.publish(pubsubMessage);
                                }
                            } catch(Exception e) {
                                String message = new StringBuilder().append("Error Publishing Messages to the Topic: ")
                                        .append("Exception: ")
                                        .append(ExceptionUtils.getStackTrace(e))
                                        .toString();

                                logger.log(Level.INFO, message);
                            }


                        } else {
                            logger.info("Unable to find UserInfo for: " + processUserIdZip11);
                        }


                    }
                } else {
                    logger.info("Unable to find principalIdZip11 for zip11: " + zip11);
                }

            }

        } catch(Exception e) {
            String message = new StringBuilder().append("Error: ")
                    .append("Exception: ")
                    .append(ExceptionUtils.getStackTrace(e))
                    .toString();

            logger.log(Level.INFO, message);
        }


    }

    public Set<String> retrievePrincipalIdZip11(JedisPool subscriberCache, String zip11) {
        try (Jedis jedis = subscriberCache.getResource()) {
            //pull the expectedId-zip11
            Set<String> principalIdZip11 = jedis.smembers("s"+ zip11);

            return principalIdZip11;
        }
    }

    public String retrieveUserInfo(JedisPool subscriberCache, String zip5, String processUserIdZip11) {
        try (Jedis jedis = subscriberCache.getResource()) {
            //pull the expectedId-zip11
            String userInfo = jedis.hget(zip5,processUserIdZip11);

            return userInfo;
        }
    }
}