package com.function;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.time.Duration;

public class SubscriberCacheConnection {

    private static volatile JedisPool jedisPoolInstance;

    private static JedisPool initialize(String host) {
        if (jedisPoolInstance != null) {
            return jedisPoolInstance;
        }

        int maxTotal = 150;
        int maxIdle = 10;
        int minIdle = 5;
        int maxWait = 45000;


        JedisPoolConfig poolConfig = new JedisPoolConfig();
        poolConfig.setMaxTotal(maxTotal);
        poolConfig.setMaxIdle(maxIdle);
        poolConfig.setMinIdle(minIdle);
        poolConfig.setMaxWait(Duration.ofMillis(maxWait));

        return new JedisPool(poolConfig, host, 6379, maxWait);
    }

    public static JedisPool getPool(String host) {
        // local variable to avoid several reads of volatile member variable
        JedisPool instance = jedisPoolInstance;

        if (instance == null) {
            synchronized (SubscriberCacheConnection.class) {
                instance = jedisPoolInstance;
                // make sure pool instance hasn't been created since waiting for lock
                if (instance == null) {
                    jedisPoolInstance = initialize(host);
                    instance = jedisPoolInstance;
                }
            }
        }

        return instance;
    }
}