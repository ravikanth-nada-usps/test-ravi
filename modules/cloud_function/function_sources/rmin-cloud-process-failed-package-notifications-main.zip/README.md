# rmin-cloud-process-failed-package-notifications

## Local Build

```shell
mvn install -D"https.protocols"=TLSv1.2
```

## Deploy 

### DEV2
### Cloud Function
```shell
gcloud functions deploy rmin-cloud-process-failed-package-notifications \
--gen2 \
--region=us-central1 \
--runtime=java17 \
--trigger-http \
--project=uspscio-idc-9060-02d \
--entry-point=com.function.CloudFunction \
--ingress-settings=INTERNAL_ONLY \
--memory=350 \
--max-instances=50 \
--egress-settings=private-ranges-only \
--vpc-connector=projects/uspscio-idc-9060-02d/locations/us-central1/connectors/rmin-dev-peripheral-conn \
--timeout=540s \
--service-account=dev-pkg-notif-processor@uspscio-idc-9060-02d.iam.gserviceaccount.com \
--set-env-vars=projectId=uspscio-idc-9060-02d,emailSubscription=rmin-package-notification-dlq-subscription-c-002d,smsSubscription=rmin-package-sms-notification-dlq-subscription-c-002d,emailTopic=rmin-package-notification-topic-c-002d,smsTopic=rmin-package-sms-notification-topic-c-002d

```
## Cloud Scheduler
```Shell
gcloud scheduler jobs create http rmin-cloud-package-email-notifications \
--schedule="0 14 * * *" \
--uri="https://us-central1-uspscio-idc-9060-02d.cloudfunctions.net/rmin-cloud-process-failed-package-notifications" \
--http-method=POST \
--message-body="email" \
--time-zone="America/Chicago" \
--headers="Content-Type=text/plain" \
--location=us-central1 \
--oidc-service-account-email="dev-pkg-notif-processor@uspscio-idc-9060-02d.iam.gserviceaccount.com" \
--description="Package Email Notification"

gcloud scheduler jobs create http rmin-cloud-package-sms-notifications \
--schedule="0 14 * * *" \
--uri="https://us-central1-uspscio-idc-9060-02d.cloudfunctions.net/rmin-cloud-process-failed-package-notifications" \
--http-method=POST \
--message-body="sms" \
--time-zone="America/Chicago" \
--headers="Content-Type=text/plain" \
--location=us-central1 \
--oidc-service-account-email="dev-pkg-notif-processor@uspscio-idc-9060-02d.iam.gserviceaccount.com" \
--description="Package Sms Notification"

```
