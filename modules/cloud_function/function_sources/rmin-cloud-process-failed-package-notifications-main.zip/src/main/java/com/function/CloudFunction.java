package com.function;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.google.cloud.functions.CloudEventsFunction;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.MessageReceiver;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.ByteString;
import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;


import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;

import io.cloudevents.CloudEvent;

public class CloudFunction implements HttpFunction {
    private static final Logger logger = Logger.getLogger(CloudFunction.class.getName());
    private Publisher publisher;

    @Override
    public void service(HttpRequest request, HttpResponse response) throws IOException {

        try {
            String notificationType = request.getReader().readLine().toString();
            if(notificationType.equals("email")) {
                publisher = PackageNotificationEmailTopic.getPubSub();
                readSub(System.getenv("emailSubscription"));
            }
            else if(notificationType.equals("sms")) {
                publisher = PackageNotificationSmsTopic.getPubSub();
                readSub(System.getenv("smsSubscription"));
            }


        } catch(Exception e) {
            String message = new StringBuilder().append("Error: ")
                    .append("Exception: ")
                    .append(ExceptionUtils.getStackTrace(e))
                    .toString();

            logger.log(Level.INFO, message);
        }

    }

    public void readSub(String subscriptionId) {
        var projectId = System.getenv("projectId");

        ProjectSubscriptionName subscriptionName =
                ProjectSubscriptionName.of(projectId, subscriptionId);

        // Instantiate an asynchronous message receiver.
        MessageReceiver receiver =
                (PubsubMessage message, AckReplyConsumer consumer) -> {
                    // Handle incoming message, then ack the received message.
                    System.out.println("Data: " + message.getData().toStringUtf8());
                    sendToTopic(message);
                    consumer.ack();
                };

        Subscriber subscriber = null;
        try {
            subscriber = Subscriber.newBuilder(subscriptionName, receiver).build();
            // Start the subscriber.
            subscriber.startAsync().awaitRunning();
            // Allow the subscriber to run for 30s unless an unrecoverable error occurs.
            subscriber.awaitTerminated(30, TimeUnit.SECONDS);
        } catch (TimeoutException timeoutException) {
            // Shut down the subscriber after 30s. Stop receiving messages.
            subscriber.stopAsync();
        }
    }

    public void sendToTopic(PubsubMessage pubsubMessage){
        try{

            publisher.publish(pubsubMessage);

        } catch(Exception e) {
            String message = new StringBuilder().append("Error Publishing Messages to the Topic: ")
                    .append("Exception: ")
                    .append(ExceptionUtils.getStackTrace(e))
                    .toString();

            logger.log(Level.INFO, message);
        }
    }

}